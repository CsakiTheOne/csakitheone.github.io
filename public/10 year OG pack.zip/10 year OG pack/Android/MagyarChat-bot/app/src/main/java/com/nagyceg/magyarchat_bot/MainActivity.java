package com.nagyceg.magyarchat_bot;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageButton;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.nagyceg.magyarchat_bot.ai.io;
import com.nagyceg.magyarchat_bot.ai.theme;

public class MainActivity extends AppCompatActivity {

    //Declare things to do stuff and give them a value
    boolean isCardVisible= false;

    //Getters
    public static Context context;
    public static Activity activity;
    public static int color;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Getters
        context = getApplicationContext();
        activity = MainActivity.this;
        color = getResources().getColor(R.color.colorPrimary);

        //Declare important things
        /*Custom card*/
        final ImageButton cardCustom = (ImageButton) findViewById(R.id.cardCustom);
        final TextView cardCustomText = (TextView) findViewById(R.id.cardCustomText);

        //Info button
        final Button btnInfo = (Button) findViewById(R.id.btnInfo);
        btnInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(getActivity())
                        .setMessage("Megkérheted a robotot, hogy dobjon egy dobókockát, " +
                                "dobjon föl egy érmét vagy keressen valamit Google segítségével.\n\n" +
                                "Alul a küldés gomb mellett van egy menü gomb is. Ott kártyák vannak," +
                                "amik különböző dolgokat csinálnak.")
                        .setTitle("Segítség").setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }).create().show();
            }
        });
        //Hide cards
        final CardView ccSearch = (CardView) findViewById(R.id.ccSearch),
                ccMap = (CardView) findViewById(R.id.ccMap),
                ccYoutube = (CardView) findViewById(R.id.ccYoutube),
                ccHistory = (CardView) findViewById(R.id.ccHistory),
                ccMemory = (CardView) findViewById(R.id.ccMemory);
        ccSearch.setVisibility(View.GONE);
        ccMap.setVisibility(View.GONE);
        ccYoutube.setVisibility(View.GONE);
        ccHistory.setVisibility(View.GONE);
        ccMemory.setVisibility(View.GONE);
        //Declare msg button, editText, msgView and getting ready
        final ImageButton btnSend = (ImageButton) findViewById(R.id.btnSend);
        final EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        final ScrollView msgsView = (ScrollView) findViewById(R.id.msgsView);
        //Show/Hide cards
        final ImageButton btnShowHideCards = (ImageButton) findViewById(R.id.btnShowHideCards);
        final HorizontalScrollView viewCards = (HorizontalScrollView) findViewById(R.id.viewCards);
        viewCards.setVisibility(View.GONE);
        btnShowHideCards.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(isCardVisible)
                {
                    viewCards.setVisibility(View.GONE);
                    isCardVisible = false;
                }
                else
                {
                    viewCards.setVisibility(View.VISIBLE);
                    isCardVisible = true;
                    /*Hide keyboard*/editTextInput.onEditorAction(EditorInfo.IME_ACTION_DONE);
                }
                //Load settings
                //TODO set text to custom card
            }
        });
        //Declare msg boxes
        final TextView msgUser1 = (TextView) findViewById(R.id.msgUser1);
        final TextView msgBot1 = (TextView) findViewById(R.id.msgBot1);
        final TextView msgUser2 = (TextView) findViewById(R.id.msgUser2);
        final TextView msgBot2= (TextView) findViewById(R.id.msgBot2);
        final TextView msgUser3 = (TextView) findViewById(R.id.msgUser3);
        final TextView msgBot3 = (TextView) findViewById(R.id.msgBot3);
        final TextView msgUser4 = (TextView) findViewById(R.id.msgUser4);
        final TextView msgBot4 = (TextView) findViewById(R.id.msgBot4);
        final TextView msgUser5 = (TextView) findViewById(R.id.msgUser5);
        final TextView msgBot5 = (TextView) findViewById(R.id.msgBot5);
        //Hide msg boxes
        final CardView msgUser1v = (CardView) findViewById(R.id.msgUser1v);
        final CardView msgBot1v = (CardView) findViewById(R.id.msgBot1v);
        final CardView msgUser2v = (CardView) findViewById(R.id.msgUser2v);
        final CardView msgBot2v = (CardView) findViewById(R.id.msgBot2v);
        final CardView msgUser3v = (CardView) findViewById(R.id.msgUser3v);
        final CardView msgBot3v = (CardView) findViewById(R.id.msgBot3v);
        final CardView msgUser4v = (CardView) findViewById(R.id.msgUser4v);
        final CardView msgBot4v = (CardView) findViewById(R.id.msgBot4v);
        final CardView msgUser5v = (CardView) findViewById(R.id.msgUser5v);
        final CardView msgBot5v = (CardView) findViewById(R.id.msgBot5v);
        msgUser1v.setVisibility(View.GONE);
        msgBot1v.setVisibility(View.GONE);
        msgUser2v.setVisibility(View.GONE);
        msgBot2v.setVisibility(View.GONE);
        msgUser3v.setVisibility(View.GONE);
        msgBot3v.setVisibility(View.GONE);
        msgUser4v.setVisibility(View.GONE);
        msgBot4v.setVisibility(View.GONE);
        msgUser5v.setVisibility(View.GONE);
        msgBot5v.setVisibility(View.GONE);
        //Send msg
        btnSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Process msg
                io.send(editTextInput.getText().toString());
                String answer = io.getAnswer();
                //Show output
                switch (io.msgc)
                {
                    case 1:
                    {
                        msgUser1.setText(editTextInput.getText());
                        msgUser1v.setVisibility(View.VISIBLE);
                        msgBot1.setText(answer);
                        msgBot1v.setVisibility(View.VISIBLE);
                        break;
                    }
                    case 2:
                    {
                        msgUser2.setText(editTextInput.getText());
                        msgUser2v.setVisibility(View.VISIBLE);
                        msgBot2.setText(answer);
                        msgBot2v.setVisibility(View.VISIBLE);
                        break;
                    }
                    case 3:
                    {
                        msgUser3.setText(editTextInput.getText());
                        msgUser3v.setVisibility(View.VISIBLE);
                        msgBot3.setText(answer);
                        msgBot3v.setVisibility(View.VISIBLE);
                        break;
                    }
                    case 4:
                    {
                        msgUser4.setText(editTextInput.getText());
                        msgUser4v.setVisibility(View.VISIBLE);
                        msgBot4.setText(answer);
                        msgBot4v.setVisibility(View.VISIBLE);
                        break;
                    }
                    case 5:
                    {
                        msgUser5.setText(editTextInput.getText());
                        msgUser5v.setVisibility(View.VISIBLE);
                        msgBot5.setText(answer);
                        msgBot5v.setVisibility(View.VISIBLE);
                        break;
                    }
                    default:
                    {
                        msgUser1.setText(msgUser2.getText());
                        msgBot1.setText(msgBot2.getText());
                        msgUser2.setText(msgUser3.getText());
                        msgBot2.setText(msgBot3.getText());
                        msgUser3.setText(msgUser4.getText());
                        msgBot3.setText(msgBot4.getText());
                        msgUser4.setText(msgUser5.getText());
                        msgBot4.setText(msgBot5.getText());
                        msgUser5.setText(editTextInput.getText());
                        msgUser5v.setVisibility(View.VISIBLE);
                        msgBot5.setText(answer);
                        msgBot5v.setVisibility(View.VISIBLE);
                    }
                }
                //Clear textbox
                editTextInput.setText("");
                //Scroll down and show / hide info button
                if(msgUser1.getVisibility() == View.GONE)btnInfo.setVisibility(View.VISIBLE);
                else btnInfo.setVisibility(View.GONE);
                msgsView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        msgsView.post(new Runnable() {
                            public void run() {
                                msgsView.fullScroll(View.FOCUS_DOWN);
                            }
                        });
                    }
                });
            }
        });
        //Cards
        //Google search
        ImageButton cardSearch = (ImageButton) findViewById(R.id.cardSearch);
        cardSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO card.search
            }
        });
        //Custom card
        cardCustom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO card.custom
            }
        });
        //Youtube (YouTube)
        ImageButton cardYoutube = (ImageButton) findViewById(R.id.cardYoutube);
        cardYoutube.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //TODO card.youtube
            }
        });
        //Settings
        ImageButton cardSettings = (ImageButton) findViewById(R.id.cardSettings);
        cardSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                btnShowHideCards.performClick();
            }
        });
        //More card
        TextView cardMore = (TextView) findViewById(R.id.cardMore);
        cardMore.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(getActivity())
                        .setMessage("Vannak olyan kártyák, amik csak akkor jönnek elő, ha kellenek " +
                                "vagy olyan a téma.\n\nPéldául:\n-Google keresés\n-YouTube")
                        .setTitle("Mégtöbb kártya").setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                    }
                }).create().show();
            }
        });
    }
    //Getters
    public static Context getContext()
    {
        return context;
    }
    public static Activity getActivity()
    {
        return activity;
    }
    public static int getColor()
    {
        return color;
    }
}
