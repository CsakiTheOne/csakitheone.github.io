﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rebel_cave_clicker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        double speed = 0, click = 0, max = 0, tick = 0, maxTick = 10;

        private void button1_SizeChanged(object sender, EventArgs e)
        {
            if (button1.Height != button1.Width) button1.Height = button1.Width;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            maxTick = 1000 / timerSec.Interval;
            if (!timerSec.Enabled) timerSec.Start();
            click++;
        }

        private void buttonShare_Click(object sender, EventArgs e)
        {
            button1.PerformClick();
            if (textBoxName.Text.Trim().Length > 0)
            {
                Thread t = new Thread(Post);
                object data = new string[]
                {
                "https://discordapp.com/api/webhooks/423585964749881354/ZJjmfua-HDckgzMoPP1sJhLBG0K_MBJg2krlksKkdxVE20v1tKcTljlIVNTLGtY3NHgc",
                "**Rebel cave clicker:** " + textBoxName.Text + " clicked " + max + " times a second. :mouse_three_button:"
                };
                t.Start(data);
            }
            else
            {
                MessageBox.Show("Írj be egy nevet megosztás előtt pls!");
            }
        }

        private void timerSec_Tick(object sender, EventArgs e)
        {
            speed = click;
            if (speed > max) max = speed;
            labelSpeed.Text = speed + " cps" + Environment.NewLine + max + " cps" + Environment.NewLine + "1 second: " + tick + " / " + maxTick;
            tick++;
            if (tick >= maxTick)
            {
                click = 0;
                tick = 0;
            }
        }

        void Post(object Data)
        {
            string[] data = (string[])Data;
            var httpWebRequest = (HttpWebRequest)WebRequest.Create(data[0]);
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";

            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = "{\"content\":\"" + data[1] + "\"}";

                streamWriter.Write(json);
                streamWriter.Flush();
                streamWriter.Close();
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                var result = streamReader.ReadToEnd();
            }
        }
    }
}
