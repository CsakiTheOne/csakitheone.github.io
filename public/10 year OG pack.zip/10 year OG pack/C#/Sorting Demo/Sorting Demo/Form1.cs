﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sorting_Demo
{
    public partial class Form1 : Form
    {
        //Declaration
        static int[] array = new int[5];
        static Panel[] cols = new Panel[5];
        //
        //Constructor and loading
        //
        public Form1()
        {
            InitializeComponent();
            comboBox1.Text = "Buborék rendezés";
            for (int i = 0; i < cols.Length; i++)
            {
                cols[i] = new Panel();
                cols[i].Width = 50;
                cols[i].Height = 10;
                cols[i].BackColor = Color.Black;
                cols[i].Top = panel1.Height - 15;
                cols[i].Left = 55 + i * 55;
            }
            panel1.Controls.AddRange(cols);
        }
        //
        //Draw columns
        //
        private void drawCol()
        {
            for (int i = 0; i < array.Length; i++)
            {
                cols[i].Top = panel1.Height - 15 - array[i] * 10;
                cols[i].Height = panel1.Height - cols[i].Top;
            }
        }
        //
        //Random generálás
        //
        private void buttonRdm_Click(object sender, EventArgs e)
        {
            Random r = new Random();
            for (int i = 0; i < array.Length; i++)
            {
                try { array[i] = r.Next((int)numMin.Value, (int)numMax.Value); } catch { array[i] = r.Next((int)numMax.Value, (int)numMin.Value); }
                drawCol();
            }
            buttonStep.Enabled = true;
            buttonSort.Enabled = true;
        }
        //
        //Step by step sort
        //
        int step, substep;
        bool doneStep;
        private void buttonStep_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Buborék rendezés")
            {
                switch (step)
                {
                    case 0:
                        {
                            if (!doneStep)
                            {
                                step++;
                                buttonStep.PerformClick();
                            }
                            else
                            {
                                doneStep = false;
                                substep = 0;
                                buttonStep.Text = "Rendezés lépésenként";
                                buttonStep.Enabled = false;
                                buttonSort.Enabled = false;
                            }
                            break;
                        }
                    case 1:
                        {
                            doneStep = true;
                            substep = 0;
                            step++;
                            buttonStep.PerformClick();
                            break;
                        }
                    case 2:
                        {
                            if (substep < array.Length - 1)
                            {
                                buttonStep.Text = "Rendezés lépésenként (" + (substep + 1) + ". és " + (substep + 2) + ". oszlop tesztelése)";
                                if (array[substep] > array[substep + 1])
                                {
                                    int temp = array[substep];
                                    array[substep] = array[substep + 1];
                                    array[substep + 1] = temp;
                                    doneStep = false;
                                    drawCol();
                                }
                                substep++;
                            }
                            else
                            {
                                step = 0;
                                buttonStep.PerformClick();
                            }
                            break;
                        }
                }
            }
            else if (comboBox1.Text == "Minimum kiválasztó rendezés")
            {
                switch (step)
                {
                    case 0:
                        {
                            if (substep < array.Length - 1)
                            {
                                step++;
                                buttonStep.PerformClick();
                            }
                            else
                            {
                                substep = 0;
                                buttonStep.Text = "Rendezés lépésenként";
                                buttonStep.Enabled = false;
                                buttonSort.Enabled = false;
                            }
                            break;
                        }
                    case 1:
                        {
                            buttonStep.Text = "Rendezés lépésenként (" + (substep + 1) + ". oszlop tesztelése)";
                            for (int j = substep + 1; j < array.Length; j++)
                            {
                                if (array[j] < array[substep])
                                {
                                    int temp = array[substep];
                                    array[substep] = array[j];
                                    array[j] = temp;
                                    drawCol();
                                }
                            }
                            substep++;
                            step--;
                            break;
                        }
                }
            }
        }
        //
        //Auto sort
        //
        private void buttonSort_Click(object sender, EventArgs e)
        {
            buttonStep.Enabled = false;
            buttonSort.Enabled = false;
            if (comboBox1.Text == "Buborék rendezés")
            {
                buttonStep.Text = "Rendezés lépésenként";
                bool done = false;
                while (!done)
                {
                    done = true;
                    for (int i = 0; i < array.Length - 1; i++)
                    {
                        if (array[i] > array[i + 1])
                        {
                            int temp = array[i];
                            array[i] = array[i + 1];
                            array[i + 1] = temp;
                            done = false;
                            drawCol();
                        }
                    }
                }
            }
            else if (comboBox1.Text == "Minimum kiválasztó rendezés")
            {
                for (int i = 0; i < array.Length - 1; i++)
                {
                    for (int j = i + 1; j < array.Length; j++)
                    {
                        if (array[j] < array[i])
                        {
                            int temp = array[i];
                            array[i] = array[j];
                            array[j] = temp;
                            drawCol();
                        }
                    }
                }
            }
        }
        //
        //Téma
        //
        private void világosTémaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = SystemColors.Control;
            ForeColor = SystemColors.ControlText;
            panel1.BackColor = Color.White;
            comboBox1.BackColor = SystemColors.Window;
            numMin.BackColor = SystemColors.Window;
            numMax.BackColor = SystemColors.Window;
            comboBox1.ForeColor = SystemColors.WindowText;
            numMin.ForeColor = SystemColors.WindowText;
            numMax.ForeColor = SystemColors.WindowText;
            for (int i = 0; i < cols.Length; i++)
                cols[i].BackColor = Color.Black;
        }
        private void átállokASötétOldalraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            BackColor = Color.FromArgb(255, 32, 32, 32);
            ForeColor = Color.White;
            panel1.BackColor = Color.Black;
            comboBox1.BackColor = Color.FromArgb(255, 32, 32, 32);
            numMin.BackColor = Color.FromArgb(255, 32, 32, 32);
            numMax.BackColor = Color.FromArgb(255, 32, 32, 32);
            comboBox1.ForeColor = Color.White;
            numMin.ForeColor = Color.White;
            numMax.ForeColor = Color.White;
            for (int i = 0; i < cols.Length; i++)
                cols[i].BackColor = Color.FromArgb(255, 32, 32, 32);
        }
    }
}
