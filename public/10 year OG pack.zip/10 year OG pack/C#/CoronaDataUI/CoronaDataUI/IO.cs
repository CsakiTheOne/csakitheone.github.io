﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CoronaDataUI
{
    static class IO
    {
        static int MonthToInt(string month)
        {
            switch (month.ToLower())
            {
                case "január":
                    return 1;
                case "február":
                    return 2;
                case "március":
                    return 3;
                case "április":
                    return 4;
                case "május":
                    return 5;
                case "június":
                    return 6;
                case "július":
                    return 7;
                case "augusztus":
                    return 8;
                case "szeptember":
                    return 9;
                case "október":
                    return 10;
                case "november":
                    return 11;
                default:
                    return 12;
            }
        }

        public static Dictionary<DateTime, ulong> ReadData(string filename)
        {
            Dictionary<DateTime, ulong> data = new Dictionary<DateTime, ulong>();
            DateTime date = DateTime.Now;

            List<string> lines = File.ReadAllLines(filename).ToList();
            lines.RemoveAt(0);
            string[] segments;
            foreach (string line in lines)
            {
                segments = line.Split(',');
                date = new DateTime(DateTime.Now.Year, MonthToInt(segments[0]), int.Parse(segments[1]));
                data.Add(date, ulong.Parse(segments[2]));
            }

            return data;
        }
    }
}
