﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animation
{
    class Menu
    {
        public static void Start(string textBefore, string textAfter, int topOfSelectedItem, string textOfSelectedItem, int leftOfItems, int topOfMenu, int speed)
        {
            /*PARAMÉTEREK: szöveg az elem előtt, elem után, a választott elem teteje, választott elem, a menü bal oldala, az első elem teteje, sebesség*/
            int topOfBefore = 0, topOfAfter = topOfSelectedItem + 1;
            while (topOfSelectedItem > topOfMenu)
            {
                System.Threading.Thread.Sleep(speed);
                Console.Clear();
                //Selected item
                Console.SetCursorPosition(leftOfItems, topOfSelectedItem);
                Console.Write(textOfSelectedItem);
                //Text before
                if (topOfBefore < 1)
                    for (int i = 0; i < textBefore.Length; i++)
                    {
                        if (textBefore[i] == '\n')
                        {
                            textBefore = textBefore.Remove(0, i + 1);
                            break;
                        }
                    }
                Console.SetCursorPosition(0, topOfBefore);
                Console.Write(textBefore);
                //Text after
                int entersA = 0;
                for (int i = 0; i < textAfter.Length - 1; i++)
                    if (textAfter[i] == '\n') entersA++;
                if (topOfAfter + entersA >= Console.WindowHeight - 1)
                    for (int i = textAfter.Length - 1; i >= 0; i--)
                    {
                        if (textAfter[i] == '\n')
                        {
                            textAfter = textAfter.Remove(i);
                            break;
                        }
                    }
                Console.SetCursorPosition(leftOfItems, topOfAfter);
                Console.Write(textAfter);
                //Getting ready for next step
                topOfSelectedItem--;
                topOfAfter++;
            }
            while (topOfAfter < Console.WindowHeight)
            {
                System.Threading.Thread.Sleep(speed);
                Console.Clear();
                //Selected item
                Console.SetCursorPosition(leftOfItems, topOfSelectedItem);
                Console.Write(textOfSelectedItem);
                //Text after
                int enters = 0;
                for (int i = 0; i < textAfter.Length - 1; i++)
                    if (textAfter[i] == '\n') enters++;
                if (topOfAfter + enters >= Console.WindowHeight - 1)
                    for (int i = textAfter.Length - 1; i >= 0; i--)
                    {
                        if (textAfter[i] == '\n')
                        {
                            textAfter = textAfter.Remove(i);
                            break;
                        }
                    }
                Console.SetCursorPosition(leftOfItems, topOfAfter);
                Console.Write(textAfter);
                //Getting ready for next step
                topOfAfter++;
            }
        }
    }
}
