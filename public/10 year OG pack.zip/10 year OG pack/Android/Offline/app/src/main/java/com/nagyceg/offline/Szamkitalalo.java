package com.nagyceg.offline;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Random;

public class Szamkitalalo extends Activity {

    //Deklarálás (változók)-------------------------------------------------------------------------
    Random r = new Random();
    int min, max, proba, s_proba, szam;
    boolean win;
    //Deklarálás (ui)
    TextView Answer, szam_adat;
    Button btnStart, btnTipp;
    EditText tMin, tMax, tTry, tippIn;
    LinearLayout layStart, layTipp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_szamkitalalo);

        //Adatok------------------------------------------------------------------------------------
        final SharedPreferences data = getSharedPreferences("Database", MODE_PRIVATE);
        final SharedPreferences.Editor dataEditor = data.edit();
         //Inicializálás
        Answer = (TextView) findViewById(R.id.Answer);
        szam_adat = (TextView) findViewById(R.id.Szam_adat);
        btnStart = (Button) findViewById(R.id.buttonStart);
        btnTipp = (Button) findViewById(R.id.buttonTipp);
        tMin = (EditText) findViewById(R.id.tMin);
        tMax = (EditText) findViewById(R.id.tMax);
        tTry = (EditText) findViewById(R.id.tTry);
        tippIn = (EditText) findViewById(R.id.tippIn);
        layStart = (LinearLayout) findViewById(R.id.layoutStart);
        layTipp = (LinearLayout) findViewById(R.id.layoutTipp);

        //Játék előkészítése
        layStart.setVisibility(View.VISIBLE);
        layTipp.setVisibility(View.GONE);
        //Új játék
        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                min = 1;
                max = 50;
                proba = 4;
                win = false;

                try {
                    min = Integer.valueOf(tMin.getText().toString());
                } catch (NumberFormatException e) {} try {
                    max = Integer.valueOf(tMax.getText().toString());
                } catch (NumberFormatException e) {} try {
                    proba = Integer.valueOf(tTry.getText().toString());
                } catch (NumberFormatException e) {}

                s_proba = proba;
                try {
                    szam = r.nextInt(max - min + 1) + min;
                } catch (Exception e) {
                    max = min + 1000;
                    proba = 1;
                    s_proba = 1;
                    szam = r.nextInt(max - min + 1) + min;
                }
                layStart.setVisibility(View.GONE);
                layTipp.setVisibility(View.VISIBLE);
                tippIn.requestFocus();
                Answer.setText("Gondoltam egy számra " + min + " és " + max + " között. " + proba + " lehetőséged van.");
                szam_adat.setText("Ajánlott tipp kezdésként: " + ((max + min) / 2));
            }
        });
        //Tippelés
        btnTipp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                proba--;
                Answer.setText("Gondoltam egy számra " + min + " és " + max + " között. " + proba + " lehetőséged van.");
                if (Integer.valueOf(tippIn.getText().toString()) > szam)
                    if (szam_adat.getText() == "Ennél kisebb.")
                        szam_adat.setText("Ennél is kisebb.");
                    else szam_adat.setText("Ennél kisebb.");
                else if (Integer.valueOf(tippIn.getText().toString()) < szam)
                    if (szam_adat.getText() == "Ennél nagyobb.")
                        szam_adat.setText("Ennél is nagyobb.");
                    else szam_adat.setText("Ennél nagyobb.");
                else {
                    szam_adat.setText("Eltaláltad " + (s_proba - proba) + " próbálkozással");
                    layStart.setVisibility(View.VISIBLE);
                    layTipp.setVisibility(View.GONE);
                    win = true;
                    money.add((max - min) / s_proba, dataEditor);
                    Answer.setText("+" + ((max - min) / s_proba) + " pont Össz: " + money.get(data) + " pont");
                    szam = -20010220;
                }
                if (proba <= 0 && !win) {
                    Answer.setText("Nem jár jutalom. Összes pontod: " + money.get(data) + " pont");
                    szam_adat.setText("Nincs több próba! Szám: " + szam);
                    layStart.setVisibility(View.VISIBLE);
                    layTipp.setVisibility(View.GONE);
                    szam = -20010220;
                }
                tippIn.setText("");
            }
        });

    }
}
