package com.nagyceg.magyarchat_bot.ai;

public class io {
    //Get input from message
    public static int msgc = 1;
    public static String msg;
    public static String[] sentence = new String[20];
    public static void send(String text)
    {
        msg = text;
        input_process();
        theme.isChanged();
    }
    //Process input
    static void input_process()
    {
        //theme
        if(theme.who.length() > 0)
        {
            try {
                msg = msg.replace("aki", theme.who);
                msg = msg.replace("róla", theme.who);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if(theme.what.length() > 0)
        {
            try {
                msg = msg.replace("ami", theme.what);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if(theme.where.length() > 0)
        {
            try {
                msg = msg.replace("ott ", theme.who + " ");
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        process.start();
    }
    //Send output
    public static String ans;
    public static String getAnswer()
    {
        return ans;
    }
}
