package com.nagyceg.offline;

import android.content.SharedPreferences;
import android.os.Handler;

import java.util.Calendar;
import java.util.Random;

/**
 * Created by Ádám on 2016.04.29..
 */

public class ai {
    static String Answer, no[] = {
        "Erre nem tudok mit mondani...", "*cirip* *cirip*",
                "He?", "Mevan?", "Nem értem...", "Hmm..."};
    public static void read(String t, Integer min, Integer max, SharedPreferences data, SharedPreferences.Editor dataEditor, Random r) {
        //Deklarálás, beállítás, stb.
        if (min > max) max = min + 10;
        String splitted[] = t.split(" ");


        //Parancsok---------------------------------------------------------------------------------
        if (t.contains(".money.set")) {
            //Pénz H4CK
            money.set(Integer.valueOf(splitted[1]), dataEditor);
        } else if (t.contains("szia") || t.contains("Szia") || t.contains("helló") || t.contains("Helló") ||
                t.contains("szevasz") || t.contains("Szevasz") || t.contains("csá") || t.contains("Csá") ||
                t.contains("cső") || t.contains("Cső") || t.contains("hi") || t.contains("Hi")){
            //Köszönés
            sayHello(data);
        }
        //Kérdések----------------------------------------------------------------------------------
        else if(t.contains(" fordítva")){
            //Fordító
            t.replace("fordítva", "");
            String ftext = "";
            for(int i = t.length() - 9; i >= 0; i--){
                try {
                    ftext += String.valueOf(t.charAt(i));
                } catch (Exception e) {/*do nothing*/}
            }
            Answer=ftext;
        } else if (t.contains(" vagy ")) {
            //Vagy vagy
            String first, second;
            try {
                for (int i = 0; i < splitted.length; i++) {
                    if (splitted[i].equals("vagy")) {
                        first = splitted[i - 1];
                        second = splitted[i + 1];
                        if (r.nextInt(2) == 0) Answer=first;
                        else Answer=second;
                        break;
                    }
                }
            } catch (Exception e) {
                Answer="Erre nem tudok válaszolni...";
            }
        } else if (t.contains("?")) {
            //?-es kérdések
            if (t.contains("Mennyire ") || t.contains("mennyire ")) {
                Answer="Válasz: " + rdm.valasz.fokok[r.nextInt(rdm.valasz.fokok.length)];
            } else if (t.contains("Mennyi") || t.contains("mennyi") || t.contains("Hány") || t.contains("hány")) {
                /*Mennyi*/
                min = 0;
                max = 100;
                for (int i = 0; i < splitted.length; i++) {
                    if (splitted[i].equals("min")) min = Integer.valueOf(splitted[i + 1]);
                    if (splitted[i].equals("max")) max = Integer.valueOf(splitted[i + 1]);
                }
                if (t.contains("dobókocka")) {
                    min = 1;
                    max = 6;
                } else if (t.contains("Hányas ") || t.contains("hányas ")) {
                    min = 1;
                    max = 5;
                }
                String rdm = String.valueOf(r.nextInt(max - min + 1) + min);
                Answer="Válasz: " + rdm;
            } else if (t.contains("Mikor ") || t.contains("mikor ")) {
                /*mikor*/
                Answer="Válasz: " + rdm.valasz.idok[r.nextInt(rdm.valasz.idok.length)];
            } else if (t.contains("Hol ") || t.contains("hol ") || t.contains("Hov") || t.contains("hov") || t.contains("Merre ") || t.contains("merre ")) {
                /*hol*/
                Answer="Válasz: " + rdm.valasz.helyek[r.nextInt(rdm.valasz.helyek.length)];
                if (t.contains(" telefonom")) Answer="Válasz: Kezedben";
            } else if (t.contains("Milyen ") || t.contains("milyen ")) {
                /*milyen*/
                Answer="Válasz: " + rdm.valasz.tulajdonsag[r.nextInt(rdm.valasz.tulajdonsag.length)];
                if (t.contains("szín"))
                    Answer="Válasz: " + rdm.valasz.tulajdonsag[r.nextInt(7)];
            } else if (t.contains("Ki ") || t.contains("ki ")) {
                /*ki*/
                Answer="Válasz: " + rdm.valasz.cselekvok[r.nextInt(rdm.valasz.cselekvok.length)];
            } else if (t.contains("Miért ") || t.contains("miért ")) {
                /*miért*/
                Answer="Válasz: " + rdm.valasz.indokok[r.nextInt(rdm.valasz.indokok.length)];
            } else {
                //Igen vagy nem
                int rdm = r.nextInt(2);
                if (rdm == 0) Answer="Válasz: Igen";
                else Answer="Válasz: Nem";
            }
        } else if (t.contains("Nevem ") || t.contains("nevem ")) {
            //Név beállítása
            try {
                for (int i = 0; i < splitted.length; i++) {
                    if (splitted[i].equals("Nevem") || splitted[i].equals("nevem")) {
                        dataEditor.putString("name", splitted[i + 1]);
                        dataEditor.apply();
                        Answer="Az új neved " + data.getString("name", "nem tudom megjegyezni");
                        break;
                    }
                }
            } catch (Exception e) {
                Answer="Nem értem...";
            }
        } else if (t.contains("Random játék") || t.contains("random játék")) {
            //Random játék
            //TODO Pár frissítés után eltűntetni.
            Answer = "Koppints a Random játék kártyájára! A játék ezentúl ott lesz!";

        } else {
            Answer=no[r.nextInt(no.length)];
        }
        //Megjelenítés
        Main.changeElement.answer("...");
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                Main.changeElement.answer(Answer);
            }
        }, 100);
        //Legutóbbi kérdés válasz tárolása a megosztás módhoz
        dataEditor.putString("q", t);
        dataEditor.putString("a", Answer);
        dataEditor.apply();
    }

    public static void sayHello(SharedPreferences data){
        Calendar c = Calendar.getInstance();
        int hours = c.get(Calendar.HOUR_OF_DAY);
        if(hours >= 4 && hours < 10) {
            Answer="Jó reggelt " + data.getString("name", "kedves felhasználó! Állítsd be a neved") + "!";
        }
        else if(hours < 5 || hours > 22){
            String words[] = {"Aludnod kéne ", "Pihenned kéne ", "Aludnod kellene ", "Pihenned kellene "};
            Random r = new Random();
            Answer=(words[r.nextInt(words.length)] + data.getString("name", "kedves felhasználó! Állítsd be a neved") + "!");
        }
        else if(hours > 18) {
            String words[] = {"Jó éjt ", "Jó estét "};
            Random r = new Random();
            Answer=(words[r.nextInt(words.length)] + data.getString("name", "kedves felhasználó! Állítsd be a neved") + "!");
        }
        else {
            String words[] = {"Helló ", "Szia ", "Szevasz ", "Üdv "};
            Random r = new Random();
            Answer=(words[r.nextInt(words.length)] + data.getString("name", "kedves felhasználó! Állítsd be a neved") + "!");
        }
    }
}
