package com.nagyceg.magyarchat_bot;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //TODO settings

        //Unknown question
        Button btnNoqAlert = (Button) findViewById(R.id.btnNoqAlert),
                btnNoqNet = (Button) findViewById(R.id.btnNoqNet);
        btnNoqAlert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //memory.dataeditor.putString("unknown_question", "alert");
                //memory.dataeditor.apply();
                Toast.makeText(SettingsActivity.this, "Ismeretlen kérdésnél figyelmeztetés", Toast.LENGTH_SHORT).show();
            }
        });
        btnNoqNet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //memory.dataeditor.putString("unknown_question", "search");
                //memory.dataeditor.apply();
                Toast.makeText(SettingsActivity.this, "Ismeretlen kérdésnél keresés a neten", Toast.LENGTH_SHORT).show();
            }
        });
        //Custom card
        final EditText editTextCustomcard = (EditText) findViewById(R.id.editTextCustomcard);
        Button btnCustomcardDel = (Button) findViewById(R.id.btnCustomcardDel);
        btnCustomcardDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                memory.dataeditor.putString("customcard", "");
                memory.dataeditor.apply();
                editTextCustomcard.setText("");
                editTextCustomcard.clearFocus();
                editTextCustomcard.onEditorAction(EditorInfo.IME_ACTION_DONE);
                Toast.makeText(SettingsActivity.this, "Parancs törölve", Toast.LENGTH_SHORT).show();
            }
        });
        Button btnCustomcard = (Button) findViewById(R.id.btnCustomcard);
        btnCustomcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                memory.dataeditor.putString("customcard", String.valueOf(editTextCustomcard.getText()));
                memory.dataeditor.apply();
                editTextCustomcard.setText("");
                editTextCustomcard.clearFocus();
                editTextCustomcard.onEditorAction(EditorInfo.IME_ACTION_DONE);
                Toast.makeText(SettingsActivity.this, "Parancs beállítva", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
