﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Metro7
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            new FormSplash().Show();
            panelSideBar.Left = Width;
            foreach (Tile item in tileManager1.Controls)
                item.canEdited = false;
            tile1.Text = "Kilépés";
            tile2.Text = "Áthelyezés másik monitorra (bugos)";
            tileTestWindow.Text = "Tesztablak megnyitása";
            try { comboBoxLayout.Items.AddRange(Directory.GetDirectories(@"layouts\")); }
            catch { /*do nothing*/ }
        }
        //
        //Start pressed and declared mouse detector boolean
        //
        bool isOpened = false;
        bool isStartClicked = false;
        private void startButton1_Click(object sender, EventArgs e)
        {
            isStartClicked = true;
            isSettingsOpened = false;
            isOpened = false;
        }
        //
        //Timer
        //
        private void timerAnim_Tick(object sender, EventArgs e)
        {
            //Detect mouse position
            if (!isSettingsOpened && Cursor.Position.X < Left + Width && Cursor.Position.X > Left + Width - 10 && Cursor.Position.Y < 30) isOpened = true;
            if (!isSettingsOpened && (Cursor.Position.X < panelSideBar.Left - 20 || Cursor.Position.X > panelSideBar.Right + 20)) isOpened = false;
            //Open / close anim
            if (Opacity < 0.5) Opacity += 0.01;
            if (isOpened)
            {
                if (panelSideBar.Left > Width - panelSideBar.Width + 0) panelSideBar.Left -= 20;
                if (panelWindow.Top > Height - panelWindow.Height - 50) panelWindow.Top -= 25;
                if (Opacity < 0.95) Opacity += 0.05;
                else if (startButton1.animType == "close") startButton1.Open();
            }
            else
            {
                startButton1.Close();
                if (panelSideBar.Left < Width) panelSideBar.Left += 10;
                if (panelWindow.Top < Height - panelWindow.Height + 150) panelWindow.Top += 25;
                if (Opacity > 0.5) Opacity -= 0.1;
                else if (isStartClicked)
                {
                    isStartClicked = false;
                    FormMetro fm = new FormMetro();
                    fm.Left = Left;
                    fm.Top = Top;
                    fm.WindowState = FormWindowState.Maximized;
                    fm.Opacity = 0;
                    fm.Show();
                }
            }
            //Settings open / close anim
            if (isSettingsOpened)
            {
                if (panelWindow.Top > 50) panelWindow.Top -= 100;
                else { BackColor = panelSideBar.BackColor; panelSettings.Visible = isSettingsOpened; }
            }
            else
            {
                BackColor = TransparencyKey;
                panelSettings.Visible = isSettingsOpened;
                if (panelWindow.Top < Height - panelWindow.Height - 50) panelWindow.Top += 100;
            }
            //Time display
            string time = "";
            if (DateTime.Now.Hour > 9) time = DateTime.Now.Hour.ToString();
            else time = "0" + DateTime.Now.Hour;
            time += ":";
            if (DateTime.Now.Minute > 9) time += DateTime.Now.Minute.ToString();
            else time += "0" + DateTime.Now.Minute;
            time += "  " + DateTime.Now.Month + "." + DateTime.Now.Day + ".";
            labelTime.Text = time;
        }
        //
        //Settings
        //
        bool isSettingsOpened = false;
        private void labelSettings_Click(object sender, EventArgs e)
        {
            isSettingsOpened = !isSettingsOpened;
        }
        //
        //Program started on wrong monitor
        //
        Label lBadmonitor;
        private void tile2_MouseDown(object sender, MouseEventArgs e)
        {
            WindowState = FormWindowState.Normal;
            lBadmonitor = new Label()
            {
                Text = "Fogd meg bárhol az ablakot és húzd a jó monitorra. A befelyezéshez kattints duplán erre az ablakra.",
            };
            lBadmonitor.Font = new Font(lBadmonitor.Font.FontFamily, 48);
            lBadmonitor.MouseDown += new MouseEventHandler(lBadmonitor_MouseDown);
            lBadmonitor.MouseMove += new MouseEventHandler(lBadmonitor_MouseMove);
            lBadmonitor.DoubleClick += new EventHandler(lBadmonitor_DoubleClick);
            Controls.Add(lBadmonitor);
            lBadmonitor.Dock = DockStyle.Fill;
            lBadmonitor.BringToFront();
        }
        int badmonitorX, badmonitorY;
        private void lBadmonitor_MouseDown(object sender, MouseEventArgs e)
        {
            badmonitorX = e.X;
            badmonitorY = e.Y;
        }
        private void lBadmonitor_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                Left = e.X + Left - badmonitorX;
                Top = e.Y + Top - badmonitorY;
            }
        }
        private void lBadmonitor_DoubleClick(object sender, EventArgs e)
        {
            Controls.Remove(lBadmonitor);
            WindowState = FormWindowState.Maximized;
        }
        //
        //Layout
        //
        private void buttonLayoutAdd_Click(object sender, EventArgs e)
        {
            string newLayout = @"layouts\" + comboBoxLayout.Text;
            Directory.CreateDirectory(newLayout);
            comboBoxLayout.Items.Clear();
            comboBoxLayout.Items.Add("Alapértelmezett");
            comboBoxLayout.Items.AddRange(Directory.GetDirectories(@"layouts\"));
            comboBoxLayout.Text = newLayout;
            saveload.SetLayout(comboBoxLayout.Text);
        }
        private void buttonLayoutDelete_Click(object sender, EventArgs e)
        {
            try { Directory.Delete(saveload.GetLayout(), true); }
            catch { MessageBox.Show("Ezt a felületet nem lehet törölni!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            comboBoxLayout.Items.Clear();
            comboBoxLayout.Items.Add("Alapértelmezett");
            comboBoxLayout.Items.AddRange(Directory.GetDirectories(@"layouts\"));
            saveload.SetLayout("default");
            comboBoxLayout.Text = "Alapértelmezett";
        }
        private void comboBoxLayout_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxLayout.Text == "Alapértelmezett") saveload.SetLayout("default");
            else saveload.SetLayout(comboBoxLayout.Text);
        }
        //
        //Exit
        //
        private void labelExit_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
