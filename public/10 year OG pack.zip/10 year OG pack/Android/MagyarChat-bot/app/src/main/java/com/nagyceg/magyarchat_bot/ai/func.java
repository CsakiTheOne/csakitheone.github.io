package com.nagyceg.magyarchat_bot.ai;

import android.net.Uri;
import android.support.customtabs.CustomTabsIntent;

import com.nagyceg.magyarchat_bot.MainActivity;

public class func {
    public static void search(String text)
    {
        io.ans = "Már keresem is!";
        String url = "https://www.google.hu/search?num=40&newwindow=1&safe=off&site=webhp&source=hp&q=" + text;
        CustomTabsIntent.Builder builder = new CustomTabsIntent.Builder();
        builder.setToolbarColor(MainActivity.getColor());
        CustomTabsIntent customTabsIntent = builder.build();
        customTabsIntent.launchUrl(MainActivity.getActivity(), Uri.parse(url));
    }
}
