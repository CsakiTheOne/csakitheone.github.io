package com.nagyceg.offline;

public class rdm {
    public static class alap {
        static String autoComplete[] = {
                "hol vagyok?", "miért ilyen jó ez az alkalmazás?", "miért pont Offline?",
                "nevem ", "mennyit mutat a dobókocka?", "hányas lesz a dolgozatom?", "én fogok felelni?",
                "mennyire jó ez az alkalmazás?", "itt van wifi?", "mikor jön az új frissítés?",
                "van eladó bojler?", "valami fordítva"
        };
        static String rdmswitch[] = {
                "Onlin.. nem, még mindig Offline", "Nagyon Offline",
                "Nem lesz Online. Ez Offline", "Online... Ja bocs, nem ide...",
                "Kapcsold vissza!", "Oflájn", "Nem mered visszakapcsolni",
                "Kapcsolgathatod, de nem lesz Online", "Ettől nem lesz WiFi hirtelen",
                "Még mindig Offline", "enilffO", ""
        };
        static String tipp[] = {
                "Szerezz pontot játékokkal! A kő papír ollóval és a számkitalálóval is működik a jutalomosztás.",
                "A számkitaláló így jutalmaz, ha eltalálod: (maximum - minimum) / próbálkozások száma",
                "Van ötleted csomagba vagy a random játékba? Dobj egy e-mail-t! Ott van lejjebb.",
                "Ha tényleg Offline vagy, de küldenél nekem e-mail-t az ötleteiddel, akkor csak " +
                        "írj egy listát. Később is el tudod küldeni...", "Dúdolj el egy jó számot!",
                "A zene unalom ellen is jó. Én például nagyon szeretem Lindsey Stirling-et. " +
                        "Ja meg persze a zenéjét is. :D Amúgy még tudom ajánlani Tobu-t.",
                "Adhatnál ötletet, hogy mit írjak ide. Már nem jut eszembe semmi...",
                "Próbálj meg leképzelni egy új színt!",
                "Döntsd el a következő mondatról, hogy igaz vagy hamis: Ez a mondat hamis.",
                "Ha a városban/utcán vagy, akkor illedelmesen szólíts le valakit és kezdj el  beszélgetni vele!"
        };
    }
    public static class valasz {
        static String idok[] = {
                "Most", "Reggel", "Délben", "Este", "Holnap", "Jövő héten", "Tegnap", "Múlt héten",
                "Soha", "Mindig", "Amikor piros hó esik", "Majd ha fagy", "Soha napján kiskedden"
        };
        static String helyek[] = {
                "Itt", "Valahol biztos", "Űrben", "Asztal alatt", "TESCO parkolóban", "Konyhában",
                "Hűtőben",
                "Kocsmában", "Sehol", "Mindenhol", "Kezedben", "Melletted", "A reptéren",
                "Az Androméda galaxisban", "a cirkuszban",
                "a világ tetején", "az Üveghegyen túl", "ahol a kurtafarkú malac túr",
                "az Óperenciás tengeren túl", "a garázsban", "a pincében", "álmában",
                "a pszihiátriai osztályon", "a zárt osztályon", "a zenetáborban",
                "a medencében", "a parlamentben", "odaát"
        };
        static String tulajdonsag[] = {
                "Piros", "Kék", "Zöld", "Fekete", "Fehér", "Világos", "Sötét",
                "Ha elmondanám, meg kéne, hogy öljelek",
                "Nagy", "Kicsi", "Vastag", "Vékony", "Okos", "Buta", "Jó", "Rossz", "Szép", "Csúnya",
                "Szakszerű", "Olyan, mint te"
        };
        static String fokok[] = {
                "Ha elmondanám, meg kéne, hogy öljelek", "Semennyire", "Kicsit", "Nagyon", "Eszméletlenül",
                "Annyira, hogy még én sem hiszem el", "Kajakra", "Nálad jobban", "A fejlesztőnél jobban"
        };
        static String cselekvok[] = {
                "Senki", "Mindenki", "Valaki biztos", "A székely meg a fia", "Kocsmárosné aranyvirág",
                "Az alkalmazás fejlesztője", "Az összes fiú", "Az összes lány", "Akivel legutoljára beszéltél",
                "Ábel a rengetegben", "A rézf'aszú bagoly", "Harry Potter", "Deadpool",
                "Az egyik családtagod", "Akivel legutoljára selfie-ztél",
                "Ángyod térdekalácsa", "A szomszéd", "A rendőr",
                "Jehova tanúja", "A teremtő", "A mozigépész",
                "A könyv", "Agyad kósza gondolata", "A micsoda", "A kicsoda",
                "A hétszűnyű kapanyányi monyók", "A telefonod", "A részeg tengerész",
                "Az ipafai pap", "A képzelt barátod", "A képzelt barátnőd",
                "Az ezerarcú természet", "Bear Grylls", "Chuck Norris",
                "Egy kínai albérlő", "A tépőzáras ló", "A felfújható imazsámoly",
                "A katasztrófaturista", "Egy légből kapott gondolat",
                "Egy fiktív személy", "Életed szerelme", "Az anyósod", "Azahogyishívják",
                "A füstbe ment terv", "Holleanyó"
        };
        static String indokok[] = {
                "Ha elmondanám, meg kéne, hogy öljelek", "Mert valamit elcsesztél",
                "Mert a Microsoft gyártotta", "Mert most is csak telefonozol", "Mert ez a legjobb alkalmazás",
                "Mert a fejlesztő jófej (meg szerény is)", "Azért, hogy legyen mit kérdezned",
                "Mert már megetted", "Mert miért ne?", "Mert az űrlények nem viselnek kalapot",
                "Mert az űrlények nem viselnek kalapot"
        };
    }
    public static class random {
        public static class alap {
            static String hatarozok[] = {
                    "", "", "", "mögötted", "veled együtt", "részegen", "a tekintetével",
                    "melletted", "a fejeden", "szükségszerűen",
                    "elkerülhetetlenül", "magányos óráiban", "sunyi, alattomos módon",
                    "in medias res", "a gőzfürdőben",
                    "az előző életedből", "általad",
                    "Chuck Norris által", "szakszerűen", "a gázbömbőben", "menetiránnyal szemben",
                    "a szomszéd szobában", "a TESCO parkolóban", "a cirkuszban",
                    "a világ tetején", "az üveghegyen túl", "ahol a kurtafarkú malac túr",
                    "az Óperenciás tengeren túl", "a garázsban", "a pincében", "álmában",
                    "a pszihiátriai osztályon", "a zárt osztályon", "a zenetáborban",
                    "a medencében", "a parlamentben", "odaát",
                    "a törvény nevében", "születésnapod alkalmából", "egykettőre", "fogja magát és"
            };
            static String rdm3alap[] = {
                    "zavart érez az erőben", "gyapotot kapál",
                    "ápol és eltakar",
                    "rád fog esni", "gyakorolja a vanást", "pálinkát főz",
                    "lesz az új sapkád", "megváltja a világot", "összekócolja a fogaidat",
                    "kirepül az ablakon. Veled együtt", "kiégeti a retinád", "a napnál fűt",
                    "arcon pörög", "köpni, nyelni nem tud",
                    "lebetonoz", "becsavarodik",
                    "háttal ül a moziban", "bedagad", "szorulást okoz", "az agyadra megy",
                    "nem tudja melyik rendezvényen van", "lesz a feleséged", "kigyullad",
                    "karácsonyi hangulatban van", "az apád", "szimpatikusnak talál", "vedlik",
                    "izgatja a fantáziád", "fel fog robbanni", "hogyhívjákol",
                    "tortát hegeszt", "kirügyezett", "szimulál",
                    "betéved a tiltott rengetegbe", "szántani menne", "megesz reggelire",
                    "wolpertinger-ré változik", "kiszárad", "pudingot hegeszt", "megcsúszik a peronon",
                    "szivárványt hány", "téged választ", "vonatkereket pumpál",
                    "óceánt sóz", "mókázni akar",
                    "felkészül a landolásra", "kiengedi a futóművet",
                    "behúzza a futóművet", "katapultál", "kicsapja a biztosítékot",
                    "feszít a lucernában", "kontrasztanyagot izzad",
                    "hozza a formáját", "disznót vág", "WC-re akar menni", "adja az ütemet",
                    "flexel", "fölényesen vezet", "az ikertestvéred", "a képzelt barátod",
                    "a képzelt barátnőd", "elnyerte méltó bűntetését", "kiégett",
                    "megcsinálja a lehetetlent", "kolbászol", "tartózkodik",
                    "meg lett villámcsapva", "pörköltszagot áraszt",
                    "szakszerűen elmagyarázza",
                    "kitér a hitéből", "kirobbanó formában van", "visítva röhög",
                    "nem hisz a szemének", "hazudik a szájával", "már nem bírja", "sírba visz",
                    "az életével játszik", "az értelmet keresi",
                    "Kukutyinban zabot hegyez", "megküzd a sárkánnyal", "az anyósod", "egy állat",
                    "felpróbálja a muszájdzsekit", "sinen van, mint József Attila", "nagyon kemény",
                    "tol, mint a szülő anya", "tanácstalan, mint a kisközség", "számot ad hollétéről",
                    "stabil, mint a forint", "hosszabb, mint zöld", "áramot vezet", "vajat köpül",
                    "fetreng a röhögéstől",
                    "tüttyölt ratylit készít", "eltávolítja a makacs foltokat", "hupákol",
                    "szóba se áll veled", "büszkén felvállalja másságát", "levetkőzi a gátlásait",
                    "hömbölög", "az életedre esküszik", "húst klopfol",
                    "lerakódik a perem alatt", "összemegy a mosásban",
                    "flexibilis, mint a bőrösvirsli", "Simsonnal repeszt", "kiborítja a bilit",
                    "megmutatja mitől döglik a légy"
            };
        }
        //csomagok
        public static String csomagnevek[] = {"alap", "NINCS MEGVÉVE", "NINCS MEGVÉVE", "NINCS MEGVÉVE", "NINCS MEGVÉVE", "lesz ám még"};
        public static String csomagok[] = {"alap", "húsvéti", "tudományos", "informatikus", "gamer"};
        //HÚSVÉTI CSOMAG
        public static class husvet {
            static String cselekvok[] = {
                    "A lány akit lefognak", "A fiú aki locsol", "A házigazda"
            };
            static String hatarozok[] = {
                    "vödörrel a kezében", "szódás szifonnal", "csurom vízesen", "részegen"
            };
            static String rdm3alap[] = {
                    "meg lett locsolva", "le lett borítva", "piros tojást adott",
                    "megkínál pálinkával"
            };
        }
        //TUDOMÁNYOS CSOMAG
        public static class tudomany {
            static String cselekvok[] = {
                    "Egy földönkívüli", "E.T.", "Egy Brit tudós"
            };
            static String hatarozok[] = {
                    "légüres térben", "nyomás alatt", "a nagy számok törvénye szerint"
            };
            static String rdm3alap[] = {
                    "kőzetmintát elemez", "részecskéket gyorsít", "keresi az élet értelmét",
                    "kettéhasítja a teret", "visszamegy veled a jövöbe", "lakmuszpróbát végez",
                    "plazmát reszel", "átlépi a hangsebességet", "belép a hipertérbe",
                    "talált nálatok egy féreglyukat", "fúzióra lépett", "űrkutatást végez",
                    "napkitöréstől szenved", "teret hajlít", "földkörüli pályára áll", "osztódik",
                    "hormonokat termel", "beállítja az egészséges pH értéket", "korpuszkuláris",
                    "foszforeszkál", "reinkarnálódik", "szimbiózisban él", "átdiffundál",
                    "elszublimál", "karanténba tesz", "számításba veszi a lehetőségeket",
                    "súrlódási együtthatót számol", "0-val oszt", "serkenti az agysejteket"
            };
        }
        //INFORMATIKUS CSOMAG
        public static class informatika {
            static String cselekvok[] = {
                    "Az alkalmazás fejlesztője", "Egy Google fejlesztő", "Egy XDA fejlesztő"
            };
            static String hatarozok[] = {
                    "offline módban", "Windows alatt", "Linux alatt", "C++-ban", "Java-ban",
                    "egy csésze kávé mellett", "a szutyok router-e miatt", "lejárt licenc-el"
            };
            static String rdm3alap[] = {
                    "deklarál", "bugos", "kékhalált kap", "kékhalált eredményez", "nem kompatibilis",
                    "Tutorial-t néz", "hamarosan leáll", "nem található (404)", "két magos", "négy magos",
                    "saját Linux disztribúciót készít"
            };
        }
        //GAMER CSOMAG
        public static class gamer {
            static String cselekvok[] = {
                    "Az admin", "Az összes LOL játékos", "Az összes CS GO játékos", "CJ", "A Silver",
                    "Az összes Minecraft játékos", "Az összes Assassin's Creed játékos",
                    "Egy creeper", "A Rageer", "A konzoljátékos", "A szar géppel rendelkező", "A csóró",
                    "A noob"
            };
            static String hatarozok[] = {
                    "egyjátékos módban", "együttműködő módban", "többjátékos módban", "LAN partiban",
                    "MountainDew ivás közben", "500-as ping-el", "enchant-olt gyémánt karddal"
            };
            static String rdm3alap[] = {
                    "headshot-ot ad AWP-vel", "rage-el", "ragequit-ol", "AFK-ol", "Minecraft-ot modol",
                    "ki lett kick-elve", "ki lett ban-olva", "csatlakozott a játékhoz",
                    "FPS drop-ot kap", "akciós steam-en", "kifogyott a stamina-ból", "le 360° noscope-ol",
                    "benyomott egy stimpak-ot", "spam-eli a chat-et", "craftol"
            };
        }
    }
}
