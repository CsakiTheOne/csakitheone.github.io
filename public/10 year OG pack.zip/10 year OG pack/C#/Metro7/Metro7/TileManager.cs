﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metro7
{
    public partial class TileManager : Panel
    {
        //
        //Declare must have components
        //
        Timer mover = new Timer();
        //
        //Constructor and OnPaint
        //
        public TileManager()
        {
            InitializeComponent();
            MouseMove += new MouseEventHandler(tileManager_MouseMove);
            mover.Interval = 300;
            mover.Tick += new EventHandler(MoveTiles);
            mover.Start();
        }
        public TileManager(bool showContextMenuStrip)
        {
            InitializeComponent();
            MouseMove += new MouseEventHandler(tileManager_MouseMove);
            mover.Interval = 300;
            mover.Tick += new EventHandler(MoveTiles);
            mover.Start();
            if (showContextMenuStrip)
            {
                ContextMenuStrip cmenu = new ContextMenuStrip();
                ToolStripMenuItem addToolStripMenuItem = new ToolStripMenuItem("Csempe hozzáadása");
                addToolStripMenuItem.Click += new EventHandler(addTileToolStripMenuItem_Click);
                cmenu.Items.Add(addToolStripMenuItem);
                ContextMenuStrip = cmenu;
            }
        }
        protected override void OnPaint(PaintEventArgs pe)
        {
            base.OnPaint(pe);
        }
        //
        //Enable context menu
        //
        public void enableContextMenu()
        {
            ContextMenuStrip cmenu = new ContextMenuStrip();
            ToolStripMenuItem addToolStripMenuItem = new ToolStripMenuItem("Csempe hozzáadása");
            addToolStripMenuItem.Click += new EventHandler(addTileToolStripMenuItem_Click);
            cmenu.Items.Add(addToolStripMenuItem);
            ContextMenuStrip = cmenu;
        }
        //
        //Add tile
        //
        int mouseX, mouseY;
        private void tileManager_MouseMove(object sender, MouseEventArgs e)
        {
            mouseX = e.X;
            mouseY = e.Y;
        }
        private void addTileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Controls.Add(new Tile { Left = mouseX - 75, Top = mouseY - 75 });
        }
        //
        //Move tiles to place
        //
        int gridWidth = 20, gridHeight = 6;
        private void MoveTiles(object sender, EventArgs e)
        {
            foreach (Control item in Controls)
            {
                for (int i = -1; i < gridWidth; i++)
                {
                    if (item.Left - 8 > i * 150 && item.Left - 8 < (i * 150) + 75)
                    {
                        item.Left = i * 150 + 8;
                        break;
                    }
                    else if (item.Left - 8 >= (i * 150) + 75 && item.Left - 8 < (i + 1) * 150)
                    {
                        item.Left = (i + 1) * 150 + 8;
                        break;
                    }
                }
                for (int i = -1; i < gridHeight; i++)
                {
                    if (item.Top - 8 > i * 150 && item.Top - 8 < (i * 150) + 75)
                    {
                        item.Top = i * 150 + 8;
                        break;
                    }
                    else if (item.Top - 8 >= (i * 150) + 75 && item.Top - 8 < (i + 1) * 150)
                    {
                        item.Top = (i + 1) * 150 + 8;
                        break;
                    }
                }
            }
        }
    }
}
