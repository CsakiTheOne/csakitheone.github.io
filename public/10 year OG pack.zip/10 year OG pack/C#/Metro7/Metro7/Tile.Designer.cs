﻿namespace Metro7
{
    partial class Tile
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.akcióBeállításaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fájlMegnyitásaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mappaMegnyitásaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.weboldalMegnyitásaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.visszaAzAsztalraToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.kilépésAProgrambólToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.méretToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x2ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.x3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x1ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.x2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.x3ToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.x1ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.x2ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.x3ToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.ikonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.írdBeIdeAzIkonSzövegetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.karaktertáblaMegnyitásaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ikonSzínBeállításaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.színBeállításaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.átnevezésToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.törlésToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.labelIcon = new System.Windows.Forms.Label();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.ContextMenuStrip = this.contextMenuStrip1;
            this.label1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(0, 118);
            this.label1.Name = "label1";
            this.label1.Padding = new System.Windows.Forms.Padding(10, 0, 10, 5);
            this.label1.Size = new System.Drawing.Size(142, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Csempe";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            this.label1.DoubleClick += new System.EventHandler(this.átnevezésToolStripMenuItem_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.akcióBeállításaToolStripMenuItem,
            this.méretToolStripMenuItem,
            this.ikonToolStripMenuItem,
            this.színBeállításaToolStripMenuItem,
            this.átnevezésToolStripMenuItem,
            this.toolStripSeparator2,
            this.törlésToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(157, 164);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // akcióBeállításaToolStripMenuItem
            // 
            this.akcióBeállításaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fájlMegnyitásaToolStripMenuItem,
            this.mappaMegnyitásaToolStripMenuItem,
            this.weboldalMegnyitásaToolStripMenuItem,
            this.toolStripSeparator1,
            this.visszaAzAsztalraToolStripMenuItem,
            this.kilépésAProgrambólToolStripMenuItem});
            this.akcióBeállításaToolStripMenuItem.Name = "akcióBeállításaToolStripMenuItem";
            this.akcióBeállításaToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.akcióBeállításaToolStripMenuItem.Text = "Akció beállítása";
            // 
            // fájlMegnyitásaToolStripMenuItem
            // 
            this.fájlMegnyitásaToolStripMenuItem.Name = "fájlMegnyitásaToolStripMenuItem";
            this.fájlMegnyitásaToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.fájlMegnyitásaToolStripMenuItem.Text = "Fájl megnyitása";
            this.fájlMegnyitásaToolStripMenuItem.Click += new System.EventHandler(this.fájlMegnyitásaToolStripMenuItem_Click);
            // 
            // mappaMegnyitásaToolStripMenuItem
            // 
            this.mappaMegnyitásaToolStripMenuItem.Name = "mappaMegnyitásaToolStripMenuItem";
            this.mappaMegnyitásaToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.mappaMegnyitásaToolStripMenuItem.Text = "Mappa megnyitása";
            this.mappaMegnyitásaToolStripMenuItem.Click += new System.EventHandler(this.mappaMegnyitásaToolStripMenuItem_Click);
            // 
            // weboldalMegnyitásaToolStripMenuItem
            // 
            this.weboldalMegnyitásaToolStripMenuItem.Name = "weboldalMegnyitásaToolStripMenuItem";
            this.weboldalMegnyitásaToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.weboldalMegnyitásaToolStripMenuItem.Text = "Weboldal megnyitása";
            this.weboldalMegnyitásaToolStripMenuItem.Click += new System.EventHandler(this.weboldalMegnyitásaToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(185, 6);
            // 
            // visszaAzAsztalraToolStripMenuItem
            // 
            this.visszaAzAsztalraToolStripMenuItem.Name = "visszaAzAsztalraToolStripMenuItem";
            this.visszaAzAsztalraToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.visszaAzAsztalraToolStripMenuItem.Text = "Vissza az asztalra";
            this.visszaAzAsztalraToolStripMenuItem.Click += new System.EventHandler(this.visszaAzAsztalraToolStripMenuItem_Click);
            // 
            // kilépésAProgrambólToolStripMenuItem
            // 
            this.kilépésAProgrambólToolStripMenuItem.Name = "kilépésAProgrambólToolStripMenuItem";
            this.kilépésAProgrambólToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.kilépésAProgrambólToolStripMenuItem.Text = "Kilépés a programból";
            this.kilépésAProgrambólToolStripMenuItem.Click += new System.EventHandler(this.kilépésAProgrambólToolStripMenuItem_Click);
            // 
            // méretToolStripMenuItem
            // 
            this.méretToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.x1ToolStripMenuItem,
            this.x2ToolStripMenuItem1,
            this.x3ToolStripMenuItem,
            this.x1ToolStripMenuItem1,
            this.x2ToolStripMenuItem,
            this.x3ToolStripMenuItem1,
            this.x1ToolStripMenuItem2,
            this.x2ToolStripMenuItem2,
            this.x3ToolStripMenuItem2});
            this.méretToolStripMenuItem.Name = "méretToolStripMenuItem";
            this.méretToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.méretToolStripMenuItem.Text = "Méret";
            // 
            // x1ToolStripMenuItem
            // 
            this.x1ToolStripMenuItem.Name = "x1ToolStripMenuItem";
            this.x1ToolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.x1ToolStripMenuItem.Text = "1 x 1";
            this.x1ToolStripMenuItem.Click += new System.EventHandler(this.x1ToolStripMenuItem_Click);
            // 
            // x2ToolStripMenuItem1
            // 
            this.x2ToolStripMenuItem1.Name = "x2ToolStripMenuItem1";
            this.x2ToolStripMenuItem1.Size = new System.Drawing.Size(97, 22);
            this.x2ToolStripMenuItem1.Text = "1 x 2";
            this.x2ToolStripMenuItem1.Click += new System.EventHandler(this.x2ToolStripMenuItem1_Click);
            // 
            // x3ToolStripMenuItem
            // 
            this.x3ToolStripMenuItem.Name = "x3ToolStripMenuItem";
            this.x3ToolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.x3ToolStripMenuItem.Text = "1 x 3";
            this.x3ToolStripMenuItem.Click += new System.EventHandler(this.x3ToolStripMenuItem_Click);
            // 
            // x1ToolStripMenuItem1
            // 
            this.x1ToolStripMenuItem1.Name = "x1ToolStripMenuItem1";
            this.x1ToolStripMenuItem1.Size = new System.Drawing.Size(97, 22);
            this.x1ToolStripMenuItem1.Text = "2 x 1";
            this.x1ToolStripMenuItem1.Click += new System.EventHandler(this.x1ToolStripMenuItem1_Click);
            // 
            // x2ToolStripMenuItem
            // 
            this.x2ToolStripMenuItem.Name = "x2ToolStripMenuItem";
            this.x2ToolStripMenuItem.Size = new System.Drawing.Size(97, 22);
            this.x2ToolStripMenuItem.Text = "2 x 2";
            this.x2ToolStripMenuItem.Click += new System.EventHandler(this.x2ToolStripMenuItem_Click);
            // 
            // x3ToolStripMenuItem1
            // 
            this.x3ToolStripMenuItem1.Name = "x3ToolStripMenuItem1";
            this.x3ToolStripMenuItem1.Size = new System.Drawing.Size(97, 22);
            this.x3ToolStripMenuItem1.Text = "2 x 3";
            this.x3ToolStripMenuItem1.Click += new System.EventHandler(this.x3ToolStripMenuItem1_Click);
            // 
            // x1ToolStripMenuItem2
            // 
            this.x1ToolStripMenuItem2.Name = "x1ToolStripMenuItem2";
            this.x1ToolStripMenuItem2.Size = new System.Drawing.Size(97, 22);
            this.x1ToolStripMenuItem2.Text = "3 x 1";
            this.x1ToolStripMenuItem2.Click += new System.EventHandler(this.x1ToolStripMenuItem2_Click);
            // 
            // x2ToolStripMenuItem2
            // 
            this.x2ToolStripMenuItem2.Name = "x2ToolStripMenuItem2";
            this.x2ToolStripMenuItem2.Size = new System.Drawing.Size(97, 22);
            this.x2ToolStripMenuItem2.Text = "3 x 2";
            this.x2ToolStripMenuItem2.Click += new System.EventHandler(this.x2ToolStripMenuItem2_Click);
            // 
            // x3ToolStripMenuItem2
            // 
            this.x3ToolStripMenuItem2.Name = "x3ToolStripMenuItem2";
            this.x3ToolStripMenuItem2.Size = new System.Drawing.Size(97, 22);
            this.x3ToolStripMenuItem2.Text = "3 x 3";
            this.x3ToolStripMenuItem2.Click += new System.EventHandler(this.x3ToolStripMenuItem2_Click);
            // 
            // ikonToolStripMenuItem
            // 
            this.ikonToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.írdBeIdeAzIkonSzövegetToolStripMenuItem,
            this.toolStripTextBox1,
            this.toolStripSeparator3,
            this.karaktertáblaMegnyitásaToolStripMenuItem,
            this.ikonSzínBeállításaToolStripMenuItem});
            this.ikonToolStripMenuItem.Name = "ikonToolStripMenuItem";
            this.ikonToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.ikonToolStripMenuItem.Text = "Ikon";
            // 
            // írdBeIdeAzIkonSzövegetToolStripMenuItem
            // 
            this.írdBeIdeAzIkonSzövegetToolStripMenuItem.Name = "írdBeIdeAzIkonSzövegetToolStripMenuItem";
            this.írdBeIdeAzIkonSzövegetToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.írdBeIdeAzIkonSzövegetToolStripMenuItem.Text = "Írd be ide az ikon szöveget:";
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(100, 23);
            this.toolStripTextBox1.TextChanged += new System.EventHandler(this.toolStripTextBox1_TextChanged);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(212, 6);
            // 
            // karaktertáblaMegnyitásaToolStripMenuItem
            // 
            this.karaktertáblaMegnyitásaToolStripMenuItem.Name = "karaktertáblaMegnyitásaToolStripMenuItem";
            this.karaktertáblaMegnyitásaToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.karaktertáblaMegnyitásaToolStripMenuItem.Text = "Karaktertábla megnyitása";
            this.karaktertáblaMegnyitásaToolStripMenuItem.Click += new System.EventHandler(this.karaktertáblaMegnyitásaToolStripMenuItem_Click);
            // 
            // ikonSzínBeállításaToolStripMenuItem
            // 
            this.ikonSzínBeállításaToolStripMenuItem.Name = "ikonSzínBeállításaToolStripMenuItem";
            this.ikonSzínBeállításaToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.ikonSzínBeállításaToolStripMenuItem.Text = "Ikon szín beállítása";
            this.ikonSzínBeállításaToolStripMenuItem.Click += new System.EventHandler(this.ikonSzínBeállításaToolStripMenuItem_Click);
            // 
            // színBeállításaToolStripMenuItem
            // 
            this.színBeállításaToolStripMenuItem.Name = "színBeállításaToolStripMenuItem";
            this.színBeállításaToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.színBeállításaToolStripMenuItem.Text = "Színezés";
            this.színBeállításaToolStripMenuItem.Click += new System.EventHandler(this.színBeállításaToolStripMenuItem_Click);
            // 
            // átnevezésToolStripMenuItem
            // 
            this.átnevezésToolStripMenuItem.Name = "átnevezésToolStripMenuItem";
            this.átnevezésToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.átnevezésToolStripMenuItem.Text = "Átnevezés";
            this.átnevezésToolStripMenuItem.Click += new System.EventHandler(this.átnevezésToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(153, 6);
            // 
            // törlésToolStripMenuItem
            // 
            this.törlésToolStripMenuItem.Name = "törlésToolStripMenuItem";
            this.törlésToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.törlésToolStripMenuItem.Text = "Törlés";
            this.törlésToolStripMenuItem.Click += new System.EventHandler(this.törlésToolStripMenuItem_Click);
            // 
            // labelIcon
            // 
            this.labelIcon.ContextMenuStrip = this.contextMenuStrip1;
            this.labelIcon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelIcon.Font = new System.Drawing.Font("Microsoft Sans Serif", 50F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelIcon.Location = new System.Drawing.Point(0, 0);
            this.labelIcon.Name = "labelIcon";
            this.labelIcon.Size = new System.Drawing.Size(142, 118);
            this.labelIcon.TabIndex = 1;
            this.labelIcon.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelIcon.Click += new System.EventHandler(this.Tile_Click);
            // 
            // Tile
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.labelIcon);
            this.Controls.Add(this.label1);
            this.Name = "Tile";
            this.Size = new System.Drawing.Size(142, 142);
            this.Load += new System.EventHandler(this.Tile_Load);
            this.Click += new System.EventHandler(this.Tile_Click);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Tile_MouseDown);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Tile_MouseMove);
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem akcióBeállításaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fájlMegnyitásaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mappaMegnyitásaToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem visszaAzAsztalraToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem kilépésAProgrambólToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem színBeállításaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem átnevezésToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem törlésToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem méretToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x1ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem x2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x2ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem x3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem x3ToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem x1ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem x2ToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem x3ToolStripMenuItem2;
        private System.Windows.Forms.Label labelIcon;
        private System.Windows.Forms.ToolStripMenuItem ikonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem írdBeIdeAzIkonSzövegetToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem ikonSzínBeállításaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem weboldalMegnyitásaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem karaktertáblaMegnyitásaToolStripMenuItem;
    }
}
