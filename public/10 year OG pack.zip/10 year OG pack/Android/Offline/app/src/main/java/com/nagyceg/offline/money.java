package com.nagyceg.offline;

import android.content.SharedPreferences;

public class money {
    public static int money = 0;
    public static void set(int value, SharedPreferences.Editor dataEditor){
        money = value;
        dataEditor.putInt("money", money);
        dataEditor.apply();
    }
    public static int get(SharedPreferences data){
        money = data.getInt("money", 0);
        return money;
    }
    public static void add(int value, SharedPreferences.Editor dataEditor){
        money += value;
        dataEditor.putInt("money", money);
        dataEditor.apply();
    }
    public static void subtract(int value, SharedPreferences.Editor dataEditor){
        money -= value;
        dataEditor.putInt("money", money);
        dataEditor.apply();
    }
}
