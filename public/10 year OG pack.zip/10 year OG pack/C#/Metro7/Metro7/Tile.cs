﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Diagnostics;
using System.Windows.Forms;

namespace Metro7
{
    public partial class Tile : UserControl
    {
        //
        //Constructor and loading
        //
        public Tile()
        {
            InitializeComponent();
        }
        private void Tile_Load(object sender, EventArgs e)
        {
            if ((BackColor.R + BackColor.B + BackColor.G) / 3 > 92) ForeColor = Color.Black;
            else ForeColor = Color.White;
            label1.ForeColor = ForeColor;
        }
        //
        //Properities
        //
        [Browsable(true), Bindable(true)]
        public new string Text
        {
            get { return label1.Text; }
            set { label1.Text = value; }
        }
        public string IconText
        {
            get { return labelIcon.Text; }
            set { labelIcon.Text = value; }
        }
        public Color IconColor
        {
            get { return labelIcon.ForeColor; }
            set { labelIcon.ForeColor = value; }
        }
        public string ActionOnClick
        {
            get { return action; }
            set { action = value; }
        }
        //
        //Events
        //
        public new event MouseEventHandler MouseDown
        {
            add { labelIcon.MouseDown += value; }
            remove { labelIcon.MouseDown -= value; }
        }
        public new event MouseEventHandler MouseMove
        {
            add { labelIcon.MouseMove += value; }
            remove { labelIcon.MouseMove -= value; }
        }
        //
        //Disable edit
        //
        public bool canEdited = true;
        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            e.Cancel = !canEdited;
        }
        //
        //Moving
        //
        int tempX, tempY;
        private void Tile_MouseDown(object sender, MouseEventArgs e)
        {
            canClicked = true;
            tempX = e.X;
            tempY = e.Y;
        }
        private void Tile_MouseMove(object sender, MouseEventArgs e)
        {
            if (canEdited && e.Button == MouseButtons.Left)
            {
                canClicked = false;
                Left = (e.X + Left) - tempX;
                Top = (e.Y + Top) - tempY;
            }
        }
        //
        //Context menu items
        //
        //Actions
        bool canClicked = true;
        public string action = "";
        Form formTest;
        Label labelTest = new Label();
        Timer timerTest;
        private void Tile_Click(object sender, EventArgs e)
        {
            if (canClicked)
            {
                if (action.Contains("metro7:"))
                {
                    if (action == "metro7:desktop") try { ((Form)Parent.Parent.Parent.Parent).Close(); } catch { MessageBox.Show("Ezt az ablakot nem lehet bezárni.", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error); }
                    else if (action == "metro7:cursortest")
                    {
                        formTest = new Form();
                        labelTest.Text = "Hiba lépett fel a kurzor figyelése során.";
                        labelTest.Dock = DockStyle.Fill;
                        formTest.Controls.Add(labelTest);
                        timerTest = new Timer();
                        timerTest.Tick += new EventHandler(timerTest_tick);
                        timerTest.Interval = 10;
                        timerTest.Enabled = true;
                        formTest.TopMost = true;
                        formTest.Show();
                    }
                    else if (action == "metro7:exit") Application.Exit();
                }
                else if (action.Length > 2)
                {
                    Process.Start(action);
                    ((Form)Parent.Parent.Parent.Parent).Close();
                }
            }
        }
        private void timerTest_tick(object sender, EventArgs e)
        {
            labelTest.Text = "Kurzor helye: " + Cursor.Position.X + ":" + Cursor.Position.Y +
                "\nNyitáshoz itt kell lennie: " + (Left + Width - 10) + ":0 - " + (Left + Width) + ":" + 30;
        }
        private void fájlMegnyitásaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.ShowDialog();
            action = ofd.FileName;
            if (label1.Text == "Csempe" || label1.Text.Length < 2) label1.Text = ofd.SafeFileName;
        }
        private void mappaMegnyitásaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            fbd.ShowDialog();
            action = fbd.SelectedPath;
            if (label1.Text == "Csempe" || label1.Text.Length < 2) label1.Text = fbd.SelectedPath.Substring(fbd.SelectedPath.LastIndexOf('\\') + 1);
        }
        Form fw = new Form();
        private TextBox tbw = new TextBox();
        private void weboldalMegnyitásaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //f is declared outside
            fw.TopMost = true;
            fw.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            fw.Width = 300;
            fw.Height = 100;
            fw.Text = "Weboldal megnyitás";
            //tb is declared outside
            fw.Controls.Add(tbw);
            tbw.Left = 12;
            tbw.Top = 12;
            tbw.Width = 260;
            Button b = new Button();
            fw.Controls.Add(b);
            b.Left = 200;
            b.Top = 40;
            b.Text = "OK";
            b.Click += new EventHandler(webOk);
            fw.ShowDialog();
        }
        private void webOk(object sender, EventArgs e)
        {
            action = tbw.Text;
            fw.Close();
            if (label1.Text == "Csempe" || label1.Text.Length < 2) label1.Text = tbw.Text;
        }
        private void visszaAzAsztalraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            action = "metro7:desktop";
            if (label1.Text == "Csempe" || label1.Text.Length < 2) label1.Text = "Asztal";
        }
        private void kilépésAProgrambólToolStripMenuItem_Click(object sender, EventArgs e)
        {
            action = "metro7:exit";
            if (label1.Text == "Csempe" || label1.Text.Length < 2) label1.Text = "Kilépés";
        }
        //Size
        private void x1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //1x1
            Width = 150 - 8;
            Height = 150 - 8;
        }
        private void x2ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //1x2
            Width = 150 - 8;
            Height = 300 - 8;
        }
        private void x3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //1x3
            Width = 150 - 8;
            Height = 450 - 8;
        }
        private void x1ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //2x1
            Width = 300 - 8;
            Height = 150 - 8;
        }
        private void x2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //2x2
            Width = 300 - 8;
            Height = 300 - 8;
        }
        private void x3ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //2x3
            Width = 300 - 8;
            Height = 450 - 8;
        }
        private void x1ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            //3x1
            Width = 450 - 8;
            Height = 150 - 8;
        }
        private void x2ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            //3x2
            Width = 450 - 8;
            Height = 300 - 8;
        }
        private void x3ToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            //3x3
            Width = 450 - 8;
            Height = 450 - 8;
        }
        //Icon
        private void toolStripTextBox1_TextChanged(object sender, EventArgs e)
        {
            labelIcon.Text = toolStripTextBox1.Text;
        }
        private void karaktertáblaMegnyitásaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(@"C:\Windows\system32\charmap.exe");
        }
        private void ikonSzínBeállításaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            labelIcon.ForeColor = cd.Color;
        }
        //Color
        private void színBeállításaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog cd = new ColorDialog();
            cd.ShowDialog();
            BackColor = cd.Color;
            if ((cd.Color.R + cd.Color.B + cd.Color.G) / 3 > 92) ForeColor = Color.Black;
            else ForeColor = Color.White;
            label1.ForeColor = ForeColor;
        }
        //Rename
        Form f = new Form();
        private TextBox tb = new TextBox();
        private void átnevezésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //f is declared outside
            f.TopMost = true;
            f.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            f.Width = 300;
            f.Height = 100;
            f.Text = "Átnevezés";
            //tb is declared outside
            f.Controls.Add(tb);
            tb.Left = 12;
            tb.Top = 12;
            tb.Width = 260;
            Button b = new Button();
            f.Controls.Add(b);
            b.Left = 200;
            b.Top = 40;
            b.Text = "OK";
            b.Click += new EventHandler(renameOk);
            f.ShowDialog();
        }
        private void renameOk(object sender, EventArgs e)
        {
            label1.Text = tb.Text;
            f.Close();
        }
        //Delete
        private void törlésToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Parent.Controls.Remove(this);
        }
    }
}
