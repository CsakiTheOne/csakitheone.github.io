﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.IO;

namespace Metro7
{
    class saveload
    {
        static string layout = "default", dataFile = "data", tilesFile = "tiles";
        public static void SetLayout(string layoutName)
        {
            layout = layoutName;
            if (layout == "default")
            {
                dataFile = "data";
                tilesFile = "tiles";
            }
            else
            {
                dataFile = layout + @"\data";
                tilesFile = layout + @"\tiles";
            }
        }
        public static string GetLayout() { return layout; }
        //
        //Save
        //
        public static void SaveText(string title, string profile)
        {
            try
            {
                FileStream f = new FileStream(dataFile, FileMode.Create);
                StreamWriter sw = new StreamWriter(f);
                sw.WriteLine(title);
                sw.WriteLine(profile);
                sw.Close();
                f.Close();
            }
            catch { }
        }
        public static void SaveTiles(TileManager tiles)
        {
            try
            {
                FileStream f = new FileStream(tilesFile, FileMode.Create);
                StreamWriter sw = new StreamWriter(f);
                foreach (Tile item in tiles.Controls)
                    sw.WriteLine(item.Text + "|" + item.IconText + "|" + item.IconColor.ToArgb().ToString() + "|" + item.Left + "|" + item.Top + "|" + item.Width + "|" + item.Height + "|" + item.BackColor.ToArgb().ToString() + "|" + item.action);
                sw.Close();
                f.Close();
            }
            catch { }
        }
        public static void SaveTiles(TileManager tiles, string layoutName)
        {
            try
            {
                FileStream f = new FileStream(layoutName, FileMode.Create);
                StreamWriter sw = new StreamWriter(f);
                foreach (Tile item in tiles.Controls)
                    sw.WriteLine(item.Text + "|" + item.IconText + "|" + item.IconColor.ToArgb().ToString() + "|" + item.Left + "|" + item.Top + "|" + item.Width + "|" + item.Height + "|" + item.BackColor.ToArgb().ToString() + "|" + item.action);
                sw.Close();
                f.Close();
            }
            catch { }
        }
        //
        //Load
        //
        public static void LoadText(Control title, Control profile)
        {
            try
            {
                FileStream f = new FileStream(dataFile, FileMode.Open);
                StreamReader sr = new StreamReader(f);
                title.Text = sr.ReadLine();
                profile.Text = sr.ReadLine();
                sr.Close();
                f.Close();
            }
            catch
            {
                title.Text = "Kezdőképernyő";
                profile.Text = "Te";
            }
        }
        public static void LoadTiles(TileManager place)
        {
            try
            {
                FileStream f = new FileStream(tilesFile, FileMode.Open);
                StreamReader sr = new StreamReader(f);
                while (!sr.EndOfStream)
                {
                    string[] data = sr.ReadLine().Split('|');
                    Tile t = new Tile()
                    {
                        Text = data[0],
                        IconText = data[1],
                        IconColor = Color.FromArgb(Convert.ToInt32(data[2])),
                        Left = Convert.ToInt32(data[3]),
                        Top = Convert.ToInt32(data[4]),
                        Width = Convert.ToInt32(data[5]),
                        Height = Convert.ToInt32(data[6]),
                        BackColor = Color.FromArgb(Convert.ToInt32(data[7]))
                    };
                    t.action = data[8];
                    place.Controls.Add(t);
                }
                sr.Close();
                f.Close();
            }
            catch { /*do nothing*/ }
        }
        public static void LoadTiles(TileManager place, string layoutName)
        {
            try
            {
                FileStream f = new FileStream(layoutName, FileMode.Open);
                StreamReader sr = new StreamReader(f);
                while (!sr.EndOfStream)
                {
                    string[] data = sr.ReadLine().Split('|');
                    Tile t = new Tile()
                    {
                        Text = data[0],
                        IconText = data[1],
                        IconColor = Color.FromArgb(Convert.ToInt32(data[2])),
                        Left = Convert.ToInt32(data[3]),
                        Top = Convert.ToInt32(data[4]),
                        Width = Convert.ToInt32(data[5]),
                        Height = Convert.ToInt32(data[6]),
                        BackColor = Color.FromArgb(Convert.ToInt32(data[7]))
                    };
                    t.action = data[8];
                    place.Controls.Add(t);
                }
                sr.Close();
                f.Close();
            }
            catch { /*do nothing*/ }
        }
    }
}
