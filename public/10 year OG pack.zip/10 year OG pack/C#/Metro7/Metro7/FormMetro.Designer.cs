﻿namespace Metro7
{
    partial class FormMetro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panelTiles = new System.Windows.Forms.Panel();
            this.tileManagerUser = new Metro7.TileManager();
            this.contextMenuStripTileManager = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addTileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panelHeader = new System.Windows.Forms.Panel();
            this.textBoxProfile = new System.Windows.Forms.TextBox();
            this.textBoxTitle = new System.Windows.Forms.TextBox();
            this.panelFooter = new System.Windows.Forms.Panel();
            this.hScrollBar1 = new System.Windows.Forms.HScrollBar();
            this.labelDebug = new System.Windows.Forms.Label();
            this.contextMenuStripDebug = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.showLocationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.showSizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tesztelésBefelyezéseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.timerAnim = new System.Windows.Forms.Timer(this.components);
            this.timerStart = new System.Windows.Forms.Timer(this.components);
            this.tableLayoutPanel1.SuspendLayout();
            this.panelTiles.SuspendLayout();
            this.contextMenuStripTileManager.SuspendLayout();
            this.panelHeader.SuspendLayout();
            this.panelFooter.SuspendLayout();
            this.contextMenuStripDebug.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.Controls.Add(this.panelTiles, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panelHeader, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panelFooter, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 120F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 23F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1000, 700);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // panelTiles
            // 
            this.panelTiles.Controls.Add(this.tileManagerUser);
            this.panelTiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelTiles.Location = new System.Drawing.Point(3, 123);
            this.panelTiles.Name = "panelTiles";
            this.panelTiles.Size = new System.Drawing.Size(994, 551);
            this.panelTiles.TabIndex = 0;
            // 
            // tileManagerUser
            // 
            this.tileManagerUser.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.tileManagerUser.BackColor = System.Drawing.Color.Transparent;
            this.tileManagerUser.ContextMenuStrip = this.contextMenuStripTileManager;
            this.tileManagerUser.Location = new System.Drawing.Point(900, 3);
            this.tileManagerUser.Name = "tileManagerUser";
            this.tileManagerUser.Size = new System.Drawing.Size(10000, 545);
            this.tileManagerUser.TabIndex = 1;
            // 
            // contextMenuStripTileManager
            // 
            this.contextMenuStripTileManager.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addTileToolStripMenuItem});
            this.contextMenuStripTileManager.Name = "contextMenuStripTileManager";
            this.contextMenuStripTileManager.Size = new System.Drawing.Size(181, 26);
            // 
            // addTileToolStripMenuItem
            // 
            this.addTileToolStripMenuItem.Name = "addTileToolStripMenuItem";
            this.addTileToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.addTileToolStripMenuItem.Text = "Csempe hozzáadása";
            // 
            // panelHeader
            // 
            this.panelHeader.Controls.Add(this.textBoxProfile);
            this.panelHeader.Controls.Add(this.textBoxTitle);
            this.panelHeader.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelHeader.Location = new System.Drawing.Point(3, 3);
            this.panelHeader.Name = "panelHeader";
            this.panelHeader.Size = new System.Drawing.Size(994, 114);
            this.panelHeader.TabIndex = 0;
            // 
            // textBoxProfile
            // 
            this.textBoxProfile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxProfile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.textBoxProfile.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxProfile.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxProfile.ForeColor = System.Drawing.Color.White;
            this.textBoxProfile.Location = new System.Drawing.Point(556, 77);
            this.textBoxProfile.Name = "textBoxProfile";
            this.textBoxProfile.ReadOnly = true;
            this.textBoxProfile.Size = new System.Drawing.Size(388, 25);
            this.textBoxProfile.TabIndex = 0;
            this.textBoxProfile.TabStop = false;
            this.textBoxProfile.Text = "Te";
            this.textBoxProfile.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // textBoxTitle
            // 
            this.textBoxTitle.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTitle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.textBoxTitle.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBoxTitle.ForeColor = System.Drawing.Color.White;
            this.textBoxTitle.Location = new System.Drawing.Point(50, 38);
            this.textBoxTitle.Name = "textBoxTitle";
            this.textBoxTitle.ReadOnly = true;
            this.textBoxTitle.Size = new System.Drawing.Size(500, 73);
            this.textBoxTitle.TabIndex = 0;
            this.textBoxTitle.TabStop = false;
            this.textBoxTitle.Text = "Kezdőképernyő";
            // 
            // panelFooter
            // 
            this.panelFooter.Controls.Add(this.hScrollBar1);
            this.panelFooter.Controls.Add(this.labelDebug);
            this.panelFooter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelFooter.Location = new System.Drawing.Point(3, 680);
            this.panelFooter.Name = "panelFooter";
            this.panelFooter.Size = new System.Drawing.Size(994, 17);
            this.panelFooter.TabIndex = 1;
            // 
            // hScrollBar1
            // 
            this.hScrollBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.hScrollBar1.LargeChange = 500;
            this.hScrollBar1.Location = new System.Drawing.Point(200, 0);
            this.hScrollBar1.Maximum = 2000;
            this.hScrollBar1.Name = "hScrollBar1";
            this.hScrollBar1.Size = new System.Drawing.Size(794, 17);
            this.hScrollBar1.SmallChange = 10;
            this.hScrollBar1.TabIndex = 1;
            this.hScrollBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.hScrollBar1_Scroll);
            // 
            // labelDebug
            // 
            this.labelDebug.BackColor = System.Drawing.Color.Gainsboro;
            this.labelDebug.ContextMenuStrip = this.contextMenuStripDebug;
            this.labelDebug.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelDebug.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.1F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelDebug.ForeColor = System.Drawing.Color.Black;
            this.labelDebug.Location = new System.Drawing.Point(0, 0);
            this.labelDebug.Margin = new System.Windows.Forms.Padding(3, 0, 0, 0);
            this.labelDebug.Name = "labelDebug";
            this.labelDebug.Size = new System.Drawing.Size(200, 17);
            this.labelDebug.TabIndex = 2;
            this.labelDebug.Text = "Szerkesztés mód";
            this.labelDebug.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.labelDebug.Click += new System.EventHandler(this.label1_Click);
            // 
            // contextMenuStripDebug
            // 
            this.contextMenuStripDebug.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.showLocationToolStripMenuItem,
            this.showSizeToolStripMenuItem,
            this.tesztelésBefelyezéseToolStripMenuItem});
            this.contextMenuStripDebug.Name = "contextMenuStripDebug";
            this.contextMenuStripDebug.Size = new System.Drawing.Size(342, 70);
            // 
            // showLocationToolStripMenuItem
            // 
            this.showLocationToolStripMenuItem.Name = "showLocationToolStripMenuItem";
            this.showLocationToolStripMenuItem.Size = new System.Drawing.Size(341, 22);
            this.showLocationToolStripMenuItem.Text = "Ablak pozíciója (Y 0 kell, hogy legyen)";
            this.showLocationToolStripMenuItem.Click += new System.EventHandler(this.showLocationToolStripMenuItem_Click);
            // 
            // showSizeToolStripMenuItem
            // 
            this.showSizeToolStripMenuItem.Name = "showSizeToolStripMenuItem";
            this.showSizeToolStripMenuItem.Size = new System.Drawing.Size(341, 22);
            this.showSizeToolStripMenuItem.Text = "Ablak mérete (Monitor felbontásával kell egyeznie)";
            this.showSizeToolStripMenuItem.Click += new System.EventHandler(this.showSizeToolStripMenuItem_Click);
            // 
            // tesztelésBefelyezéseToolStripMenuItem
            // 
            this.tesztelésBefelyezéseToolStripMenuItem.Name = "tesztelésBefelyezéseToolStripMenuItem";
            this.tesztelésBefelyezéseToolStripMenuItem.Size = new System.Drawing.Size(341, 22);
            this.tesztelésBefelyezéseToolStripMenuItem.Text = "Tesztelés befelyezése";
            this.tesztelésBefelyezéseToolStripMenuItem.Click += new System.EventHandler(this.tesztelésBefelyezéseToolStripMenuItem_Click);
            // 
            // timerAnim
            // 
            this.timerAnim.Interval = 1000;
            this.timerAnim.Tick += new System.EventHandler(this.timerAnim_Tick);
            // 
            // timerStart
            // 
            this.timerStart.Interval = 10;
            this.timerStart.Tick += new System.EventHandler(this.timerStart_Tick);
            // 
            // FormMetro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.ClientSize = new System.Drawing.Size(1000, 700);
            this.Controls.Add(this.tableLayoutPanel1);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormMetro";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Metro7 UI";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormMetro_FormClosing);
            this.Load += new System.EventHandler(this.FormMetro_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panelTiles.ResumeLayout(false);
            this.contextMenuStripTileManager.ResumeLayout(false);
            this.panelHeader.ResumeLayout(false);
            this.panelHeader.PerformLayout();
            this.panelFooter.ResumeLayout(false);
            this.contextMenuStripDebug.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panelHeader;
        private System.Windows.Forms.Panel panelFooter;
        private System.Windows.Forms.TextBox textBoxTitle;
        private System.Windows.Forms.Panel panelTiles;
        private TileManager tileManagerUser;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripTileManager;
        private System.Windows.Forms.ToolStripMenuItem addTileToolStripMenuItem;
        private System.Windows.Forms.TextBox textBoxProfile;
        private System.Windows.Forms.Timer timerAnim;
        private System.Windows.Forms.Timer timerStart;
        private System.Windows.Forms.HScrollBar hScrollBar1;
        private System.Windows.Forms.Label labelDebug;
        private System.Windows.Forms.ContextMenuStrip contextMenuStripDebug;
        private System.Windows.Forms.ToolStripMenuItem showLocationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem showSizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tesztelésBefelyezéseToolStripMenuItem;
    }
}