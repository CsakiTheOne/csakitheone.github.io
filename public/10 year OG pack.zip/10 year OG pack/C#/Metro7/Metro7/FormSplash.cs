﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metro7
{
    public partial class FormSplash : Form
    {
        public FormSplash()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            double maxX = Screen.PrimaryScreen.Bounds.Width * 0.2,
                maxY = Screen.PrimaryScreen.Bounds.Height * 0.2,
                valX = Screen.PrimaryScreen.Bounds.Width - Cursor.Position.X,
                valY = Cursor.Position.Y;
            try
            {
                Opacity = ((valX / maxX) + (valY / maxY)) / 2;
                if (Convert.ToInt32(((valX / maxX) + (valY / maxY)) / 2 * 100) < 101)
                    progressBar1.Value = Convert.ToInt32(100 - ((valX / maxX) + (valY / maxY)) / 2 * 100);
                else
                    progressBar1.Value = 0;
            }
            catch
            {
                Opacity = 1;
            }
            if (Opacity < 0.07) Close();
        }
    }
}
