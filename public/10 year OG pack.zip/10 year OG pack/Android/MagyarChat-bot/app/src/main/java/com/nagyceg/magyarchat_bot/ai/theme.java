package com.nagyceg.magyarchat_bot.ai;

public class theme {
    public static String general = "0", old = "0", who, what, where;
    public static Boolean isChanged()
    {
        if(general == old)
        {
            if(io.msgc < 6)io.msgc++;
            return false;
        }
        else
        {
            io.msgc = 1;
            return true;
        }
    }
}
