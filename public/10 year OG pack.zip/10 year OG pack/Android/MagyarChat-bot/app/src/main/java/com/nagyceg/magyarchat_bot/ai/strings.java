package com.nagyceg.magyarchat_bot.ai;

public class strings {
    public static class chat
    {
        //Chat
        /*greetings*/
        public static String[] greets = {"szia", "Szia", "hello", "Hello", "helló", "Helló",
                "szeva", "Szeva", "szevasz", "Szevasz", "hali", "Hali", "csá", "Csá",
                "helóka", "Helóka"};
        /*good*/
        public static String[] good = {"az jó", "Az jó", "az nagyon jó", "Az nagyon jó", "szuper", "Szuper"};
        public static String[] gooda = {"Bizony.", "Bezany.", "Az ám.", "Jaja.", "Ahamm."};
        /*happy*/
        public static String[] happy = {":)", ":D", ";)", "boldog", "Boldog", "lol", "Lol", "xd", "XD", "örülök", "Örülök"};
        public static String[] happya = {":)", ":D", "Hehe :D"};
        /*thanks*/
        public static String[] thx = {"kösz", "Kösz"};
        public static String[] thxa = {"Nincs mit.", "Semmiség.", "Ezért vagyok."};
    }
    public static class question
    {
        //Question
        /*what's up?*/
        public static String[] qMizu = {"helyzet", "Helyzet", "mi a helyzet", "Mi a helyzet", "mizu", "Mizu"};
        public static String[] aMizu = {"Semmi, csak úgy számolgatok.", "Helyzet van, már csak gól kéne.",
                "Angolul: ''What's up?''. Erre csak mondják viccesen, hogy ''the celling''. Azaz a plafon. :D Angol humor..."};
        /*how are you?*/
        public static String[] qHogyvagy = {"hogy vagy", "Hogy vagy", "jól vagy", "Jól vagy"};
        public static String[] aHogyvagy = {"Jól vagyok.", "Köszi, jól.", "Egész jól", "Elvagyok", ":)"};
        /*what are you doing?*/
        public static String[] qDo = {"mit csinálsz", "Mit csinálsz", "mi jót csinálsz", "Mi jót csinálsz"};
        public static String[] aDo = {"Csak számolgatok.", "Semmi különlegeset.", "Veled beszélgetek. ;)"};
        /*who are you?*/
        public static String[] qWho = {"ki vagy", "Ki vagy", "mi vagy", "Mi vagy", "miért vagy", "Miért vagy",
                "miért alkottak", "Miért alkottak", "miért készített", "Miért készített"};
        public static String[] aWho = {"Egy robot vagyok és azért készítettek, hogy segítsek az embereknek.",
                "A robotod vagyok és azért készítettek, hogy segítsek"};
    }
}
