﻿namespace Metro7
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panelSideBar = new System.Windows.Forms.Panel();
            this.labelSettings = new System.Windows.Forms.Label();
            this.startButton1 = new Metro7.startButton();
            this.panelWindow = new System.Windows.Forms.Panel();
            this.labelTime = new System.Windows.Forms.Label();
            this.timerAnim = new System.Windows.Forms.Timer(this.components);
            this.panelSettings = new System.Windows.Forms.Panel();
            this.tileManager1 = new Metro7.TileManager();
            this.tile1 = new Metro7.Tile();
            this.tile2 = new Metro7.Tile();
            this.tileTestWindow = new Metro7.Tile();
            this.buttonLayoutDelete = new System.Windows.Forms.Button();
            this.buttonLayoutAdd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxLayout = new System.Windows.Forms.ComboBox();
            this.panelSideBar.SuspendLayout();
            this.panelWindow.SuspendLayout();
            this.panelSettings.SuspendLayout();
            this.tileManager1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelSideBar
            // 
            this.panelSideBar.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panelSideBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.panelSideBar.Controls.Add(this.labelSettings);
            this.panelSideBar.Controls.Add(this.startButton1);
            this.panelSideBar.Location = new System.Drawing.Point(880, 0);
            this.panelSideBar.Name = "panelSideBar";
            this.panelSideBar.Size = new System.Drawing.Size(120, 700);
            this.panelSideBar.TabIndex = 0;
            // 
            // labelSettings
            // 
            this.labelSettings.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.labelSettings.AutoSize = true;
            this.labelSettings.Location = new System.Drawing.Point(30, 413);
            this.labelSettings.Name = "labelSettings";
            this.labelSettings.Size = new System.Drawing.Size(60, 13);
            this.labelSettings.TabIndex = 1;
            this.labelSettings.Text = "Beállítások";
            this.labelSettings.Click += new System.EventHandler(this.labelSettings_Click);
            // 
            // startButton1
            // 
            this.startButton1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.startButton1.BackColor = System.Drawing.Color.Transparent;
            this.startButton1.Location = new System.Drawing.Point(0, 290);
            this.startButton1.Name = "startButton1";
            this.startButton1.Size = new System.Drawing.Size(120, 120);
            this.startButton1.TabIndex = 0;
            this.startButton1.Click += new System.EventHandler(this.startButton1_Click);
            // 
            // panelWindow
            // 
            this.panelWindow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.panelWindow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(28)))), ((int)(((byte)(28)))), ((int)(((byte)(28)))));
            this.panelWindow.Controls.Add(this.labelTime);
            this.panelWindow.Location = new System.Drawing.Point(50, 510);
            this.panelWindow.Name = "panelWindow";
            this.panelWindow.Size = new System.Drawing.Size(400, 140);
            this.panelWindow.TabIndex = 1;
            // 
            // labelTime
            // 
            this.labelTime.AutoSize = true;
            this.labelTime.Font = new System.Drawing.Font("Microsoft Sans Serif", 42F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.labelTime.Location = new System.Drawing.Point(38, 38);
            this.labelTime.Name = "labelTime";
            this.labelTime.Size = new System.Drawing.Size(168, 64);
            this.labelTime.TabIndex = 0;
            this.labelTime.Text = "00:00";
            // 
            // timerAnim
            // 
            this.timerAnim.Enabled = true;
            this.timerAnim.Interval = 40;
            this.timerAnim.Tick += new System.EventHandler(this.timerAnim_Tick);
            // 
            // panelSettings
            // 
            this.panelSettings.AutoSize = true;
            this.panelSettings.Controls.Add(this.tileManager1);
            this.panelSettings.Controls.Add(this.buttonLayoutDelete);
            this.panelSettings.Controls.Add(this.buttonLayoutAdd);
            this.panelSettings.Controls.Add(this.label1);
            this.panelSettings.Controls.Add(this.comboBoxLayout);
            this.panelSettings.Location = new System.Drawing.Point(50, 190);
            this.panelSettings.Name = "panelSettings";
            this.panelSettings.Size = new System.Drawing.Size(707, 201);
            this.panelSettings.TabIndex = 3;
            // 
            // tileManager1
            // 
            this.tileManager1.AutoSize = true;
            this.tileManager1.BackColor = System.Drawing.Color.Transparent;
            this.tileManager1.Controls.Add(this.tile1);
            this.tileManager1.Controls.Add(this.tile2);
            this.tileManager1.Controls.Add(this.tileTestWindow);
            this.tileManager1.Location = new System.Drawing.Point(3, 40);
            this.tileManager1.Name = "tileManager1";
            this.tileManager1.Size = new System.Drawing.Size(608, 155);
            this.tileManager1.TabIndex = 7;
            // 
            // tile1
            // 
            this.tile1.ActionOnClick = "metro7:exit";
            this.tile1.BackColor = System.Drawing.Color.Maroon;
            this.tile1.ForeColor = System.Drawing.Color.White;
            this.tile1.IconColor = System.Drawing.Color.White;
            this.tile1.IconText = "X";
            this.tile1.Location = new System.Drawing.Point(458, 8);
            this.tile1.Name = "tile1";
            this.tile1.Size = new System.Drawing.Size(142, 142);
            this.tile1.TabIndex = 3;
            // 
            // tile2
            // 
            this.tile2.ActionOnClick = "";
            this.tile2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.tile2.ForeColor = System.Drawing.Color.Black;
            this.tile2.IconColor = System.Drawing.Color.Black;
            this.tile2.IconText = "[  ] -> [  ]";
            this.tile2.Location = new System.Drawing.Point(158, 8);
            this.tile2.Name = "tile2";
            this.tile2.Size = new System.Drawing.Size(294, 142);
            this.tile2.TabIndex = 1;
            this.tile2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.tile2_MouseDown);
            // 
            // tileTestWindow
            // 
            this.tileTestWindow.ActionOnClick = "metro7:cursortest";
            this.tileTestWindow.BackColor = System.Drawing.Color.MidnightBlue;
            this.tileTestWindow.ForeColor = System.Drawing.Color.White;
            this.tileTestWindow.IconColor = System.Drawing.Color.White;
            this.tileTestWindow.IconText = "</>";
            this.tileTestWindow.Location = new System.Drawing.Point(8, 8);
            this.tileTestWindow.Name = "tileTestWindow";
            this.tileTestWindow.Size = new System.Drawing.Size(142, 142);
            this.tileTestWindow.TabIndex = 0;
            // 
            // buttonLayoutDelete
            // 
            this.buttonLayoutDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLayoutDelete.Location = new System.Drawing.Point(623, 11);
            this.buttonLayoutDelete.Name = "buttonLayoutDelete";
            this.buttonLayoutDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonLayoutDelete.TabIndex = 6;
            this.buttonLayoutDelete.Text = "Törlés";
            this.buttonLayoutDelete.UseVisualStyleBackColor = true;
            this.buttonLayoutDelete.Click += new System.EventHandler(this.buttonLayoutDelete_Click);
            // 
            // buttonLayoutAdd
            // 
            this.buttonLayoutAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLayoutAdd.Location = new System.Drawing.Point(542, 11);
            this.buttonLayoutAdd.Name = "buttonLayoutAdd";
            this.buttonLayoutAdd.Size = new System.Drawing.Size(75, 23);
            this.buttonLayoutAdd.TabIndex = 5;
            this.buttonLayoutAdd.Text = "Új felület";
            this.buttonLayoutAdd.UseVisualStyleBackColor = true;
            this.buttonLayoutAdd.Click += new System.EventHandler(this.buttonLayoutAdd_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(16, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(364, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Csempe felület (Ajánlott minden eszközre külön felület az elérési utak miatt.):";
            // 
            // comboBoxLayout
            // 
            this.comboBoxLayout.BackColor = System.Drawing.SystemColors.Window;
            this.comboBoxLayout.ForeColor = System.Drawing.SystemColors.WindowText;
            this.comboBoxLayout.FormattingEnabled = true;
            this.comboBoxLayout.Items.AddRange(new object[] {
            "Alapértelmezett"});
            this.comboBoxLayout.Location = new System.Drawing.Point(386, 13);
            this.comboBoxLayout.Name = "comboBoxLayout";
            this.comboBoxLayout.Size = new System.Drawing.Size(150, 21);
            this.comboBoxLayout.TabIndex = 3;
            this.comboBoxLayout.Text = "Alapértelmezett";
            this.comboBoxLayout.SelectedIndexChanged += new System.EventHandler(this.comboBoxLayout_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Green;
            this.ClientSize = new System.Drawing.Size(1000, 700);
            this.Controls.Add(this.panelWindow);
            this.Controls.Add(this.panelSettings);
            this.Controls.Add(this.panelSideBar);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Opacity = 0.01D;
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Form1";
            this.TopMost = true;
            this.TransparencyKey = System.Drawing.Color.Green;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panelSideBar.ResumeLayout(false);
            this.panelSideBar.PerformLayout();
            this.panelWindow.ResumeLayout(false);
            this.panelWindow.PerformLayout();
            this.panelSettings.ResumeLayout(false);
            this.panelSettings.PerformLayout();
            this.tileManager1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelSideBar;
        private System.Windows.Forms.Panel panelWindow;
        private System.Windows.Forms.Timer timerAnim;
        private System.Windows.Forms.Label labelTime;
        private System.Windows.Forms.Label labelSettings;
        private System.Windows.Forms.Panel panelSettings;
        private System.Windows.Forms.Button buttonLayoutDelete;
        private System.Windows.Forms.Button buttonLayoutAdd;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxLayout;
        private TileManager tileManager1;
        private startButton startButton1;
        private Tile tile2;
        private Tile tileTestWindow;
        private Tile tile1;
    }
}

