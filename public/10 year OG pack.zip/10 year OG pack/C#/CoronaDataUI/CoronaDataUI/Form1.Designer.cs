﻿namespace CoronaDataUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFontBig = new System.Windows.Forms.Label();
            this.canvas = new System.Windows.Forms.PictureBox();
            this.calendar = new System.Windows.Forms.MonthCalendar();
            this.btnOpen = new System.Windows.Forms.Button();
            this.numGraphPrediction = new System.Windows.Forms.NumericUpDown();
            this.lblPrediction = new System.Windows.Forms.Label();
            this.lblModifier = new System.Windows.Forms.Label();
            this.numModifier = new System.Windows.Forms.NumericUpDown();
            this.lblGF = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.canvas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGraphPrediction)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numModifier)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFontBig
            // 
            this.lblFontBig.AutoSize = true;
            this.lblFontBig.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblFontBig.Location = new System.Drawing.Point(15, 189);
            this.lblFontBig.Name = "lblFontBig";
            this.lblFontBig.Size = new System.Drawing.Size(50, 73);
            this.lblFontBig.TabIndex = 3;
            this.lblFontBig.Text = " ";
            this.lblFontBig.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // canvas
            // 
            this.canvas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.canvas.Location = new System.Drawing.Point(208, 18);
            this.canvas.Name = "canvas";
            this.canvas.Size = new System.Drawing.Size(564, 431);
            this.canvas.TabIndex = 4;
            this.canvas.TabStop = false;
            this.canvas.Paint += new System.Windows.Forms.PaintEventHandler(this.canvas_Paint);
            this.canvas.Resize += new System.EventHandler(this.canvas_Resize);
            // 
            // calendar
            // 
            this.calendar.BackColor = System.Drawing.Color.Black;
            this.calendar.ForeColor = System.Drawing.Color.White;
            this.calendar.Location = new System.Drawing.Point(18, 18);
            this.calendar.MaxSelectionCount = 1;
            this.calendar.MinDate = new System.DateTime(2020, 1, 1, 0, 0, 0, 0);
            this.calendar.Name = "calendar";
            this.calendar.TabIndex = 5;
            this.calendar.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.calendar_DateChanged);
            // 
            // btnOpen
            // 
            this.btnOpen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btnOpen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.btnOpen.Location = new System.Drawing.Point(12, 389);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(190, 60);
            this.btnOpen.TabIndex = 6;
            this.btnOpen.Text = "Fájl betöltése";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // numGraphPrediction
            // 
            this.numGraphPrediction.Location = new System.Drawing.Point(18, 205);
            this.numGraphPrediction.Name = "numGraphPrediction";
            this.numGraphPrediction.Size = new System.Drawing.Size(178, 20);
            this.numGraphPrediction.TabIndex = 7;
            this.numGraphPrediction.ValueChanged += new System.EventHandler(this.numGraphPrediction_ValueChanged);
            // 
            // lblPrediction
            // 
            this.lblPrediction.AutoSize = true;
            this.lblPrediction.Location = new System.Drawing.Point(12, 189);
            this.lblPrediction.Name = "lblPrediction";
            this.lblPrediction.Size = new System.Drawing.Size(70, 13);
            this.lblPrediction.TabIndex = 8;
            this.lblPrediction.Text = "Előre vetítés:";
            // 
            // lblModifier
            // 
            this.lblModifier.AutoSize = true;
            this.lblModifier.Location = new System.Drawing.Point(12, 228);
            this.lblModifier.Name = "lblModifier";
            this.lblModifier.Size = new System.Drawing.Size(86, 13);
            this.lblModifier.TabIndex = 9;
            this.lblModifier.Text = "Jóslás módosító:";
            // 
            // numModifier
            // 
            this.numModifier.Location = new System.Drawing.Point(18, 244);
            this.numModifier.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numModifier.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            -2147483648});
            this.numModifier.Name = "numModifier";
            this.numModifier.Size = new System.Drawing.Size(178, 20);
            this.numModifier.TabIndex = 10;
            this.numModifier.ValueChanged += new System.EventHandler(this.numModifier_ValueChanged);
            // 
            // lblGF
            // 
            this.lblGF.AutoSize = true;
            this.lblGF.Location = new System.Drawing.Point(15, 267);
            this.lblGF.Name = "lblGF";
            this.lblGF.Size = new System.Drawing.Size(16, 13);
            this.lblGF.TabIndex = 11;
            this.lblGF.Text = "...";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(40)))), ((int)(((byte)(40)))));
            this.ClientSize = new System.Drawing.Size(784, 461);
            this.Controls.Add(this.lblGF);
            this.Controls.Add(this.numModifier);
            this.Controls.Add(this.lblModifier);
            this.Controls.Add(this.lblPrediction);
            this.Controls.Add(this.numGraphPrediction);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.calendar);
            this.Controls.Add(this.canvas);
            this.Controls.Add(this.lblFontBig);
            this.ForeColor = System.Drawing.Color.White;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MinimumSize = new System.Drawing.Size(500, 300);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.Text = "CoronaData UI";
            ((System.ComponentModel.ISupportInitialize)(this.canvas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numGraphPrediction)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numModifier)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblFontBig;
        private System.Windows.Forms.PictureBox canvas;
        private System.Windows.Forms.MonthCalendar calendar;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.NumericUpDown numGraphPrediction;
        private System.Windows.Forms.Label lblPrediction;
        private System.Windows.Forms.Label lblModifier;
        private System.Windows.Forms.NumericUpDown numModifier;
        private System.Windows.Forms.Label lblGF;
    }
}

