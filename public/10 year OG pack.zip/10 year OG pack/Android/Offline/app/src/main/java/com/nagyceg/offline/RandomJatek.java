package com.nagyceg.offline;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Random;

public class RandomJatek extends Activity {

    //Deklarálás
    TextView rdmMondat;
    ImageButton fab;
    Spinner s1, s2, s3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_random_jatek);
        //Adatok------------------------------------------------------------------------------------
        final SharedPreferences data = getSharedPreferences("Database", MODE_PRIVATE);
        final SharedPreferences.Editor dataEditor = data.edit();
        //final SharedPreferences.Editor dataEditor = data.edit();
        //Inicializálás
        rdmMondat = (TextView) findViewById(R.id.rdmMondat);
        fab = (ImageButton) findViewById(R.id.fabRdm);
        s1 = (Spinner) findViewById(R.id.spinner1);
        s2 = (Spinner) findViewById(R.id.spinner2);
        s3 = (Spinner) findViewById(R.id.spinner3);
        //Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, rdm.random.csomagnevek);
        s1.setAdapter(adapter);
        s2.setAdapter(adapter);
        s3.setAdapter(adapter);
        try {
            s1.setSelection(data.getInt("pack1id", 0));
            s2.setSelection(data.getInt("pack2id", 0));
            s3.setSelection(data.getInt("pack3id", 0));
        }catch (Exception e){/*do nothing*/}
        s1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String s;
                s = rdm.random.csomagnevek[position];
                dataEditor.putString("pack1", s);
                dataEditor.putInt("pack1id", position);
                dataEditor.apply();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        s2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String s;
                s = rdm.random.csomagnevek[position];
                dataEditor.putString("pack2", s);
                dataEditor.putInt("pack2id", position);
                dataEditor.apply();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        s3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String s;
                s = rdm.random.csomagnevek[position];
                dataEditor.putString("pack3", s);
                dataEditor.putInt("pack3id", position);
                dataEditor.apply();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //FAB
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random r = new Random();
                String p1, p2, p3;
                p1=rdm.valasz.cselekvok[r.nextInt(rdm.valasz.cselekvok.length)];
                p2=rdm.random.alap.hatarozok[r.nextInt(rdm.random.alap.hatarozok.length)];
                p3=rdm.random.alap.rdm3alap[r.nextInt(rdm.random.alap.rdm3alap.length)];
                //Csomag tesztelése-------------------------------------------------------------------------
                //TODO Csomagok tesztelése
                //Húsvéti csomag
                if(data.getString("pack1","alap").equals("húsvéti")
                        )p1= rdm.random.husvet.cselekvok[r.nextInt(rdm.random.husvet.cselekvok.length)];
                if(data.getString("pack2","alap").equals("húsvéti")
                        )p2= rdm.random.husvet.hatarozok[r.nextInt(rdm.random.husvet.hatarozok.length)];
                if(data.getString("pack3","alap").equals("húsvéti")
                        )p3= rdm.random.husvet.rdm3alap[r.nextInt(rdm.random.husvet.rdm3alap.length)];
                //Tudományos csomag
                if(data.getString("pack1","alap").equals("tudományos")
                        )p1= rdm.random.tudomany.cselekvok[r.nextInt(rdm.random.tudomany.cselekvok.length)];
                if(data.getString("pack2","alap").equals("tudományos")
                        )p2= rdm.random.tudomany.hatarozok[r.nextInt(rdm.random.tudomany.hatarozok.length)];
                if(data.getString("pack3","alap").equals("tudományos")
                        )p3= rdm.random.tudomany.rdm3alap[r.nextInt(rdm.random.tudomany.rdm3alap.length)];
                //Informatikus csomag
                if(data.getString("pack1","alap").equals("informatikus")
                        )p1= rdm.random.informatika.cselekvok[r.nextInt(rdm.random.informatika.cselekvok.length)];
                if(data.getString("pack2","alap").equals("informatikus")
                        )p2= rdm.random.informatika.hatarozok[r.nextInt(rdm.random.informatika.hatarozok.length)];
                if(data.getString("pack3","alap").equals("informatikus")
                        )p3= rdm.random.informatika.rdm3alap[r.nextInt(rdm.random.informatika.rdm3alap.length)];
                //Gamer csomag
                if(data.getString("pack1","alap").equals("gamer")
                        )p1= rdm.random.gamer.cselekvok[r.nextInt(rdm.random.gamer.cselekvok.length)];
                if(data.getString("pack2","alap").equals("gamer")
                        )p2= rdm.random.gamer.hatarozok[r.nextInt(rdm.random.gamer.hatarozok.length)];
                if(data.getString("pack3","alap").equals("gamer")
                        )p3= rdm.random.gamer.rdm3alap[r.nextInt(rdm.random.gamer.rdm3alap.length)];
                //Kimenet-----------------------------------------------------------------------------------
                String out = p1+" "+p2+" "+p3+".";
                rdmMondat.setText(out);
            }
        });
    }
}
