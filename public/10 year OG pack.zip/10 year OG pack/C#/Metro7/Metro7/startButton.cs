﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metro7
{
    public partial class startButton : UserControl
    {
        public startButton()
        {
            InitializeComponent();
        }
        //
        //Click event
        //
        [Browsable(true)]
        public new event EventHandler Click
        {
            add { panel0.Click += value; panel1.Click += value; panel2.Click += value; panel3.Click += value; panel4.Click += value; }
            remove { panel0.Click -= value; panel1.Click -= value; panel2.Click -= value; panel3.Click -= value; panel4.Click -= value; }
        }
        //
        //Animate
        //
        public string animType = "";
        private int speed = 3;
        public void Open()
        {
            animType = "open";
        }
        public void Close()
        {
            animType = "close";
        }
        private void TimerAnim_Tick(object sender, EventArgs e)
        {
            if (animType == "open")
            {
                if (panel1.Left > 27)
                {
                    panel1.Left -= speed;
                    panel1.Top -= speed;
                    panel2.Left += speed;
                    panel2.Top -= speed;
                    panel3.Left -= speed;
                    panel3.Top += speed;
                    panel4.Left += speed;
                    panel4.Top += speed;
                }
            }
            else if(animType == "close")
            {
                if (panel1.Left < 45)
                {
                    panel1.Left += speed;
                    panel1.Top += speed;
                    panel2.Left -= speed;
                    panel2.Top += speed;
                    panel3.Left += speed;
                    panel3.Top -= speed;
                    panel4.Left -= speed;
                    panel4.Top -= speed;
                }
            }
        }
    }
}
