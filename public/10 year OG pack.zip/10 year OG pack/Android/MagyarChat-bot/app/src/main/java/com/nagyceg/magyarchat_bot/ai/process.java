package com.nagyceg.magyarchat_bot.ai;

import java.util.Random;

public class process {
    public static void start()
    {
        io.ans = "";
        Random r = new Random();
        for(int x = 0; x < io.sentence.length; x++)
        {
            String temp = "";
            //start
            //chat
            /*greeting*/
            for(int i = 0; i < strings.chat.greets.length; i++)
                if (io.sentence[x].contains(strings.chat.greets[i])) {
                    temp = strings.chat.greets[r.nextInt(strings.chat.greets.length)];
                    String temp_st = String.valueOf(temp.charAt(0)).toUpperCase();
                    temp = temp_st + temp.substring(1);
                }
            /*Good*/
            for (int i = 0; i < strings.chat.good.length; i++)
                if (io.sentence[x].contains(strings.chat.good[i]))
                    temp = strings.chat.gooda[r.nextInt(strings.chat.gooda.length)];
            /*Happy*/
            for (int i = 0; i < strings.chat.happy.length; i++)
                if (io.sentence[x].contains(strings.chat.happy[i]))
                    temp = strings.chat.happya[r.nextInt(strings.chat.happya.length)];
            /*Thank you*/
            for (int i = 0; i < strings.chat.thx.length; i++)
                if (io.sentence[x].contains(strings.chat.thx[i]))
                    temp = strings.chat.thxa[r.nextInt(strings.chat.thxa.length)];
            //question
            //Q:what's up?
            for (int i = 0; i < strings.question.qMizu.length; i++)
                if (io.sentence[x].contains(strings.question.qMizu[i])) temp = strings.question.aMizu[r.nextInt(strings.question.aMizu.length)];
            //Q:how are you?
            for (int i = 0; i < strings.question.qHogyvagy.length; i++)
                if (io.sentence[x].contains(strings.question.qHogyvagy[i])) temp = strings.question.aHogyvagy[r.nextInt(strings.question.aHogyvagy.length)];
            //Q:what are you doing?
            for (int i = 0; i < strings.question.qDo.length; i++)
                if (io.sentence[x].contains(strings.question.qDo[i])) temp = strings.question.aDo[r.nextInt(strings.question.aDo.length)];
            //Q:who are you?
            for (int i = 0; i < strings.question.qWho.length; i++)
                if (io.sentence[x].contains(strings.question.qWho[i])) temp = strings.question.aWho[r.nextInt(strings.question.aWho.length)];
            //Unknown question
            if(temp.equals("")) {
                try {
                    //Search
                    if(io.sentence[x].contains("ki az a") || io.sentence[x].contains("Ki az a") ||
                            io.sentence[x].contains("kik azok a") || io.sentence[x].contains("Kik azok a") ||
                            io.sentence[x].contains("mi az a") || io.sentence[x].contains("Mi az a") ||
                            io.sentence[x].contains("mik azok a") || io.sentence[x].contains("Mik azok a"))
                    {
                        String txtToSearch = "";
                        txtToSearch = io.s_word[x][3];
                        for(int i = 4; i < io.s_word[x].length; i++)
                        {
                            txtToSearch += " " + io.s_word[x][i];
                        }
                        func.search(txtToSearch);
                    }
                    else func.search(io.sentence[x]);

                } catch (Exception e) {
                    io.ans = "Erre a kérdésre nem tudok válaszolni.";
                }
            }
            //end
            io.ans += temp;
        }
    }
}
