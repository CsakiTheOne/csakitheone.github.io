package com.nagyceg.offline;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class KoPapirOllo extends Activity {

    //Deklarálás------------------------------------------------------------------------------------
    int game = 0;
    Spinner title;
    FloatingActionButton fabKo, fabPapir, fabOllo;
    String you;
    TextView Answer, desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kpo);
        //Adatok------------------------------------------------------------------------------------
        final SharedPreferences data = getSharedPreferences("Database", MODE_PRIVATE);
        final SharedPreferences.Editor dataEditor = data.edit();
        //Inicializálás
        title = (Spinner) findViewById(R.id.title);
        fabKo = (FloatingActionButton) findViewById(R.id.fabKo);
        fabPapir = (FloatingActionButton) findViewById(R.id.fabPapir);
        fabOllo = (FloatingActionButton) findViewById(R.id.fabOllo);
        Answer = (TextView) findViewById(R.id.Answer);
        desc = (TextView) findViewById(R.id.gameDesc);
        //Cím---------------------------------------------------------------------------------------
        String games[] = {"Kő Papír Olló", "Egy régi népi játék"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(KoPapirOllo.this, R.layout.support_simple_spinner_dropdown_item, games);
        title.setAdapter(adapter);
        title.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Answer.setText("Nyomd meg az egyik gombot!");
                if(position == 0){
                    desc.setText("A hagyományos kő papír olló játék.\nSemmi különleges. " +
                            "Csak annyi, hogy ezért kapsz pontot.");
                    fabKo.show();
                    fabPapir.show();
                    fabOllo.show();
                } else if(position == 1) {
                    desc.setText("Volt egy játék, amit egy fiú és egy lány játszott.\n" +
                            "Mindketten leültek egy székre, egymásnak háttal és egy harmadik ember fogta a fejüket. " +
                            "Mikor elengedte, a fiúnak és a lánynak egymásra kellett néznie, valamelyik irányba fordulva. " +
                            "Ha ellenkező irányba fordultak (egyik jobbra, másik balra), akkor a lány egy csókkal* tartozott a fiúnak. " +
                            "\n\n*=Pusziról van szó, de régen így nevezték.\n\nAjánlott a játék kipróbálása a valóságban!");
                    fabKo.show();
                    fabPapir.hide();
                    fabOllo.show();
                }
                game = position;
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        //Gombok lenyomása--------------------------------------------------------------------------
        fabKo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                you = "Kő";
                if(game == 0)playKPO(data, dataEditor);
                if(game == 1)playNepijatek(you);
            }
        });
        fabPapir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                you = "Papír";
                if(game == 0)playKPO(data, dataEditor);
            }
        });
        fabOllo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                you = "Olló";
                if(game == 0)playKPO(data, dataEditor);
                if(game == 1)playNepijatek(you);
            }
        });
        //Gombok hosszú nyomása---------------------------------------------------------------------
        fabKo.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(KoPapirOllo.this, "Kő / Balra", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        fabPapir.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(KoPapirOllo.this, "Papír", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        fabOllo.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                Toast.makeText(KoPapirOllo.this, "Olló / Jobbra", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
    }

    void playKPO(SharedPreferences data, SharedPreferences.Editor dataEditor){
        Random r = new Random();
        //Kő, papír, olló
        int n = r.nextInt(3) + 1;
        String s = "";
        if (n == 1) s = "Kő";
        else if (n == 2) s = "Papír";
        else if (n == 3) s = "Olló";
        String out = "Te: " + you + "\nTelefon: " + s;
        if (you.equals("Kő") && s.equals("Olló") || you.equals("Papír") && s.equals("Kő") || you.equals("Olló") && s.equals("Papír")) {
            int x = 1;
            money.add(x, dataEditor);
            Toast.makeText(getApplicationContext(), "+"+x+" pont Össz: " + money.get(data) + "pont", Toast.LENGTH_SHORT).show();
        }
        if (you.equals("Kő") && s.equals("Papír") || you.equals("Papír") && s.equals("Olló") || you.equals("Olló") && s.equals("Kő")) {
            Toast.makeText(getApplicationContext(), "Nem nyertél.", Toast.LENGTH_SHORT).show();
        }
        Answer.setText(out);
        //ANTISPAM
        fabKo.setClickable(false);
        fabPapir.setClickable(false);
        fabOllo.setClickable(false);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                fabKo.setClickable(true);
                fabPapir.setClickable(true);
                fabOllo.setClickable(true);
            }
        }, 800);
    }

    void playNepijatek(String y){
        if(y == "Kő")y = "Balra";
        else y = "Jobbra";

        Random r = new Random();
        int n = r.nextInt(2);
        String s = "";
        if (n == 0) s = "Jobbra";
        else if (n == 1) s = "Balra";

        Answer.setText("Te: " + y + "\nŐ: " + s);

        if(!y.equals(s))Answer.setText(Answer.getText() + "\nJár a csók!");
        else Answer.setText(Answer.getText() + "\nNem kapsz semmit.");
        Answer.setVisibility(View.INVISIBLE);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            public void run() {
                Answer.setVisibility(View.VISIBLE);
            }
        }, 100);
    }
}
