package com.nagyceg.offline;

import java.lang.Exception;
import java.lang.Integer;
import java.lang.Override;
import java.lang.String;
import java.util.Calendar;
import java.util.Random;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class Main extends AppCompatActivity {

    //Deklarálás------------------------------------------------------------------------------------
    /*fabok*/static FloatingActionButton fab, clear, fab_settings;
    /*szövegdoboz*/static AutoCompleteTextView editText;
    /*szöveg*/static TextView HelpName, Answer, textkpo;
    /*gombok*/static ImageButton share; static Button tipp, cardKPO, cardSzam, cardRdm;
    Switch kapcs;
    //Változók deklarálása----------------------------------------------------------------------
    String text;
    Random r = new Random();
    int min = 0, max = 10, gondolt_szam = -20010220, proba = 3, s_proba = 3;
    boolean szamkitalalo_win = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //App Starting
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //Inicializálás-----------------------------------------------------------------------------
        //FAB-ok
        fab = (FloatingActionButton) findViewById(R.id.fab);
        clear = (FloatingActionButton) findViewById(R.id.clear);
        fab_settings = (FloatingActionButton) findViewById(R.id.fab_settings);
        //Egyéb
        HelpName = (TextView) findViewById(R.id.textSetName);
        Answer = (TextView) findViewById(R.id.textAnswer);
        textkpo = (TextView) findViewById(R.id.textKPO);
        kapcs = (Switch) findViewById(R.id.switch1);
        //Gombok
        share = (ImageButton) findViewById(R.id.share);
        tipp = (Button) findViewById(R.id.textTipp);
        cardKPO = (Button) findViewById(R.id.textViewHelpKpo);
        cardSzam = (Button) findViewById(R.id.textViewHelpSzamkitalalo);
        cardRdm = (Button) findViewById(R.id.textViewHelpRdmGame);

        //Adatok------------------------------------------------------------------------------------
        final SharedPreferences data = getSharedPreferences("Database", MODE_PRIVATE);
        final SharedPreferences.Editor dataEditor = data.edit();
        //Pénz betöltése----------------------------------------------------------------------------
        money.set(data.getInt("money", 0), dataEditor);
        //Csomagok betöltése------------------------------------------------------------------------
        for(int i = 1; i < rdm.random.csomagok.length; i++)
            if(data.getBoolean("isHave" + i, false) == true)rdm.random.csomagnevek[i] = rdm.random.csomagok[i];
        //Kő Papír Olló-----------------------------------------------------------------------------
        cardKPO.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), KoPapirOllo.class));
            }
        });
        //Számkitaláló------------------------------------------------------------------------------
        cardSzam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), Szamkitalalo.class));
            }
        });
        //Random Játék------------------------------------------------------------------------------
        cardRdm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), RandomJatek.class));
            }
        });
        //Tipp--------------------------------------------------------------------------------------
        tipp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tipp.setText("\nTipp:\n" + rdm.alap.tipp[r.nextInt(rdm.alap.tipp.length)] + "\n");
            }
        });
        //Kapcsoló----------------------------------------------------------------------------------
        kapcs.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(kapcs.isChecked()){
                    kapcs.setText("" + rdm.alap.rdmswitch[r.nextInt(rdm.alap.rdmswitch.length)]);
                }else{
                    kapcs.setText("Offline");
                }
            }
        });
        //AutoComplete------------------------------------------------------------------------------
        editText = (AutoCompleteTextView) findViewById(R.id.editText);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, rdm.alap.autoComplete);
        editText.setThreshold(0);
        editText.setAdapter(adapter);
        //Stb.--------------------------------------------------------------------------------------
        textkpo.setVisibility(View.GONE);
        //Név tesztelése és köszönés----------------------------------------------------------------
        if(!data.getString("name", "...").equals("...")){HelpName.setVisibility(View.GONE);}
        ai.sayHello(data);
        //RANDOM JUTALOM----------------------------------------------------------------------------
        {
            int x, y = 0;
            x = r.nextInt(100)+1;
            if(x <= 60)y = 0;
            else if(x <= 90)y = 1;
            else if(x <= 98)y = 5;
            else if(x <= 99)y = 10;
            else if(x <= 100)y = 20;
            money.add(y, dataEditor);
            if(y != 0)Toast.makeText(Main.this, "Random jutalom: +" + y + " pont", Toast.LENGTH_LONG).show();
        }
    //FAB-------------------------------------------------------------------------------------------
    clear.hide();
    fab.setOnClickListener(new View.OnClickListener()

    {
        @Override
        public void onClick(View v) {
            text = editText.getText().toString();
            clear.show();

            ai.read(text, min, max, data, dataEditor, r);

            //Név teszt
            if (!data.getString("name", "...").equals("...")) {
                HelpName.setVisibility(View.GONE);
            }
        }
    });
        //Beállítások-------------------------------------------------------------------------------
        fab_settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(), SettingsActivity.class));
            }
        });
        //Megosztás---------------------------------------------------------------------------------
        share.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!clear.isShown()) {
                    fab.callOnClick();
                }
                startActivity(new Intent(getApplicationContext(), FullscreenActivity.class));
            }
        });
        //Törlés------------------------------------------------------------------------------------
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setText("");
                min = 0;
                max = 10;
                gondolt_szam = -20010220;
                proba = 3;
                s_proba = 3;
                Calendar c = Calendar.getInstance();
                int hours = c.get(Calendar.HOUR_OF_DAY);
                if(hours >= 4 && hours < 10) {
                    Answer.setText("Jó reggelt " + data.getString("name", "kedves felhasználó! Állítsd be a neved") + "!");
                }
                else if(hours < 5 || hours > 22){
                    Answer.setText(data.getString("name", "Kedves felhasználó! Állítsd be a neved") + "! Aludnod kéne.");
                }
                else if(hours > 18) {
                    Answer.setText("Jó éjt " + data.getString("name", "kedves felhasználó! Állítsd be a neved") + "!");
                }
                else {
                    String words[] = {"Helló ", "Szia ", "Szevasz "};
                    Answer.setText(words[r.nextInt(words.length)] + data.getString("name", "kedves felhasználó! Állítsd be a neved") + "!");
                }
                textkpo.setVisibility(View.GONE);
                clear.hide();
            }
        });

    }
    //Kérdés kilépésnél-----------------------------------------------------------------------------
    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this)
                .setMessage("Biztos ki szeretnél lépni?")
                .setPositiveButton("Igen", new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Ne felejts értékelni az áruházban, ha még nem tetted!", Toast.LENGTH_LONG).show();
                        finish();
                    }

                })
                .setNegativeButton("Nem", null)
                .show();
    }
//For other classes --------------------------------------------------------------------------------
    public static class changeElement {
        public static void txtbox(String text){
            editText.setText(text);
        }
        public static void answer(String text){
            Answer.setText(text);
        }
    }
}

