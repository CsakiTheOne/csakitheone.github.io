package com.nagyceg.offline;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;

public class FullscreenActivity extends Activity {

    TextView tq, ta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fullscreen);

        tq = (TextView) findViewById(R.id.textQ);
        ta = (TextView) findViewById(R.id.textA);
        //Adatok
        SharedPreferences data = getSharedPreferences("Database", MODE_PRIVATE);
        tq.setText(data.getString("q", "Mi a francér' nem működik ez?"));
        ta.setText(data.getString("a", "Lehet, hogy nem kérdeztél még semmit."));

        tq.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
                return false;
            }
        });

        ta.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN);
                return false;
            }
        });
    }

}
