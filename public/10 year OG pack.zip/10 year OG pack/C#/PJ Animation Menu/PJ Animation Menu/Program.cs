﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PJ_Animation_Menu
{
    class Program
    {
        static void Menu()
        {
            Console.Clear();
            Console.SetCursorPosition(2, 2);
            Console.Write("Menu");
            Console.SetCursorPosition(2, 4);
            Console.Write("1. Elem");
            Console.SetCursorPosition(2, 6);
            Console.Write("2. Elem");
            Console.SetCursorPosition(2, 8);
            Console.Write("3. Elem");
            Console.SetCursorPosition(2, 10);
            Console.Write("4. Elem");
            Console.SetCursorPosition(2, 12);
            Console.Write("5. Kilépés");
            char s = Console.ReadKey().KeyChar;
            switch (s)
            {
                case '1':
                    {
                        Animation.Menu.Start("  Menu", "\n\n  2. Elem\n\n  3. Elem\n\n  4. Elem\n\n  5. Kilépés", 4, "1. Elem", 2, 2, 50);
                        Console.ReadKey();
                        break;
                    }
                case '2':
                    {
                        Animation.Menu.Start("  Menu\n\n  1. Elem", "\n\n  3. Elem\n\n  4. Elem\n\n  5. Kilépés", 6, "2. Elem", 2, 2, 50);
                        Console.ReadKey();
                        break;
                    }
                case '3':
                    {
                        Animation.Menu.Start("  Menu\n\n  1. Elem\n\n  2. Elem", "\n\n  4. Elem\n\n  5. Kilépés", 8, "3. Elem", 2, 2, 50);
                        Console.ReadKey();
                        break;
                    }
                case '4':
                    {
                        Animation.Menu.Start("  Menu\n\n  1. Elem\n\n  2. Elem\n\n  3. Elem", "\n\n  5. Kilépés", 10, "4. Elem", 2, 2, 50);
                        Console.ReadKey();
                        break;
                    }
                case '5':
                    {
                        Animation.Menu.Start("  Menu\n\n  1. Elem\n\n  2. Elem\n\n  3. Elem\n\n  4. Elem", "\n\n  5. Kilépés", 12, "", 2, 2, 50);
                        break;
                    }
            }
            System.Threading.Thread.Sleep(200);
            if (s != '5') Menu();
        }
        static void Main(string[] args)
        {
            Menu();
        }
    }
}
