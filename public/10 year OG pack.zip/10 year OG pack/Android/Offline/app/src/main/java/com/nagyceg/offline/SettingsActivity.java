package com.nagyceg.offline;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class SettingsActivity extends Activity {

    //Declare views---------------------------------------------------------------------------------
    Button s_money, setName, packs, packInform, packGamer, packTudomany, packHusvet;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        //Find views
        s_money = (Button) findViewById(R.id.settings_money);
        setName = (Button) findViewById(R.id.settings_setName);
        packs = (Button) findViewById(R.id.settings_packs);
        packHusvet = (Button) findViewById(R.id.settings_packHusvet);
        packTudomany = (Button) findViewById(R.id.settings_packTudomany);
        packInform = (Button) findViewById(R.id.settings_packInform);
        packGamer = (Button) findViewById(R.id.settings_packGamer);
        //Adatok
        final SharedPreferences data = getSharedPreferences("Database", MODE_PRIVATE);
        final SharedPreferences.Editor dataEditor = data.edit();
        load();
        //Code
        setName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Main.changeElement.txtbox("Régi név " + data.getString("name", "nem volt") + ". Új nevem ");
                SettingsActivity.this.finish();
            }
        });
        //Csomagok----------------------------------------------------------------------------------
        packHusvet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shop(data, dataEditor, 1, 80);
            }
        });
        packTudomany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shop(data, dataEditor, 2, 100);
            }
        });
        packInform.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shop(data, dataEditor, 3, 256);
            }
        });
        packGamer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                shop(data, dataEditor, 4, 420);
            }
        });
    }

    protected void shop(SharedPreferences data, SharedPreferences.Editor dataEditor, Integer num, Integer cost){
        if (!data.getBoolean("isHave" + num, false)) {
            if (money.get(data) >= cost) {
                rdm.random.csomagnevek[num] = rdm.random.csomagok[num];
                dataEditor.putBoolean("isHave" + num, true);
                dataEditor.apply();
                money.subtract(cost, dataEditor);
            } else
                Toast.makeText(getApplicationContext(), "Nincs elég pontod", Toast.LENGTH_SHORT).show();
        } else
            Toast.makeText(getApplicationContext(), "Már megvan ez a csomag", Toast.LENGTH_SHORT).show();
        dataEditor.apply();
        load();
    }

    protected void load(){
        //Adatok
        SharedPreferences data = getSharedPreferences("Database", MODE_PRIVATE);
        SharedPreferences.Editor dataEditor = data.edit();
        s_money.setText("Pontjaid: " + money.get(data));
        setName.setText("A neved: " + data.getString("name", "Még nincs beállítva") + "\nBeállításhoz koppints ide.");
        try {
            packs.setText("\nRandom játék csomagok\n\nA random játék különböző csomagokból válogathat, amiket lejjebb tudsz beállítani.\n" +
                    "\nJelenlegi beállítás:\n" +
                    data.getString("pack1", "ismeretlen") + " cselekvők\n" + data.getString("pack2", "ismeretlen") + " határozók\n" + data.getString("pack3", "ismeretlen") + " aktivitások\n");
        }catch (Exception e){
            dataEditor.putString("pack1", "alap");
            dataEditor.putString("pack2", "alap");
            dataEditor.putString("pack3", "alap");
            dataEditor.putInt("pack1id", 0);
            dataEditor.putInt("pack2id", 0);
            dataEditor.putInt("pack3id", 0);
            dataEditor.apply();
            load();
        }
    }
}
