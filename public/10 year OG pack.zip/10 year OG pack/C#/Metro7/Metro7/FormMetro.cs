﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Metro7
{
    public partial class FormMetro : Form
    {
        public FormMetro()
        {
            InitializeComponent();
        }

        private void FormMetro_Load(object sender, EventArgs e)
        {
            tileManagerUser.Left = (int)(Width * 1.5);
            tileManagerUser.enableContextMenu();
            //Load data
            saveload.LoadTiles(tileManagerUser);
            saveload.LoadText(textBoxTitle, textBoxProfile);
            //Start animation and timert
            timerStart.Start();
        }
        //
        //Scroll
        //
        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            tileManagerUser.Left = 3 - hScrollBar1.Value;
        }
        //
        //Edit texts
        //
        private void label1_Click(object sender, EventArgs e)
        {
            if (!textBoxTitle.ReadOnly)
            {
                labelDebug.Text = "Szerkesztés mód";
                textBoxTitle.ReadOnly = true;
                textBoxProfile.ReadOnly = true;
                labelDebug.Focus();
                if (textBoxTitle.Text.Trim().Length < 1) textBoxTitle.Text = "Kezdőképernyő";
                if (textBoxProfile.Text.Trim().Length < 1) textBoxProfile.Text = "Te";
            }
            else
            {
                labelDebug.Text = "Szerkesztés befelyezése";
                textBoxTitle.ReadOnly = false;
                textBoxProfile.ReadOnly = false;
                labelDebug.Focus();
            }
        }
        private void setEditModeText()
        {
            if (textBoxTitle.ReadOnly) labelDebug.Text = "Szerkesztés mód";
            else labelDebug.Text = "Szerkesztés befelyezése";
        }
        //
        //Form closing
        //
        bool isClosing = false;
        private void FormMetro_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!isClosing) e.Cancel = true;
            isClosing = true;
            timerAnim.Interval = 10;
        }
        //
        //Timer
        //
        private void timerStart_Tick(object sender, EventArgs e)
        {
            Opacity += 0.2;

            if (tileManagerUser.Left > 4)
            {
                tileManagerUser.Left -= tileManagerUser.Left / 15 + 2;
            }
            else
            {
                tileManagerUser.Left = tileManagerUser.Top;
                timerAnim.Start();
                timerStart.Stop();
            }
        }
        private void timerAnim_Tick(object sender, EventArgs e)
        {
            saveload.SaveTiles(tileManagerUser);
            saveload.SaveText(textBoxTitle.Text, textBoxProfile.Text);
            if (isClosing)
            {
                if (Opacity > 0)
                {
                    Opacity -= 0.05;
                }
                else
                {
                    Close();
                }
            }
            setEditModeText();
            if (debugType == "location")
                labelDebug.Text += " | " + Location.ToString();
            else if (debugType == "size")
                labelDebug.Text += " | " + Size.ToString();
        }
        //Debug label
        string debugType = "";
        private void showLocationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            debugType = "location";
        }
        private void showSizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            debugType = "size";
        }
        private void tesztelésBefelyezéseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            debugType = "";
        }
    }
}